# -*- coding:utf-8 -*-

# SpeedRetopo Add-on
# Copyright (C) 2016 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy
from bpy.types import Menu, Header,Panel,Operator
from .icon.icons import load_icons
import bmesh


def get_addon_preferences():
    addon_key = __package__.split(".")[0]
    return bpy.context.preferences.addons[addon_key].preferences

def is_bsurface_activated():
    return any('bsurfaces' in addon.lower() for addon in bpy.context.preferences.addons.keys())
    # addon_name = "bsurface"
    # return addon_name in bpy.context.preferences.addons

def is_looptools_activated():
    return any('looptools' in addon.lower() for addon in bpy.context.preferences.addons.keys())
    # addon_name = "looptools"
    # return addon_name in bpy.context.preferences.addons



# UI
class SPEEDRETOPO_PT_ui(Panel):
    bl_label = "SpeedRetopo"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tools"

    def draw_header(self, context):
        layout = self.layout
        icons = load_icons()
        icon = icons.get("icon_speedretopo")
        layout.label(text="", icon_value=icon.icon_id)

    def draw(self, context):
        layout = self.layout
        if context.object is not None and len(context.selected_objects) == 1:
            SpeedRetopo(self, context)
        elif len(context.selected_objects) == 0:
            layout.label(text="Select An Object", icon='ERROR')
        else:
            layout.label(text="Selection Only One Object", icon='ERROR')
# Panel
def get_mesh_info(obj):
    bpy.context.area.tag_redraw()
    depsgraph = bpy.context.evaluated_depsgraph_get()
    evaluated_obj = obj.evaluated_get(depsgraph)
    faces = evaluated_obj.data.polygons
    face_count = len(faces)
    triangle_count = sum(len(poly.vertices) - 2 for poly in faces)
    print ("toto")
    return face_count, triangle_count

class SPEEDRETOPO_OT_tooltip_number_faces(Operator):
    bl_idname = "object.speedretopo_tooltip_number_faces"
    bl_label = "Number of Faces and Triangles"
    bl_description = ("Number of faces/Triangles of the Reference Object\n\n"
                      "A huge number of Faces may decrease The performances of the Computer.\n"
                      "You can Decimate the Reference Object\n\n"
                      "Note:\n\n"
                      "Don't forget to make a Backup of the Referenc Object before Applying the Decimate Modifier")

    def execute(self, context):
        return {'FINISHED'}

def ui_ref_object(self,context,layout,obj,buttons_size,spg,icons,addonPref):
    box = layout.box()
    split = box.split()
    col = split.column(align=True)
    row = col.row(align=True)
    row.label(text="REFERENCE OBJECT")
    row = col.row(align=True)
    row.scale_y = buttons_size
    row.prop(spg, "ref_object", text="", icon='MESH_MONKEY')

    if addonPref.show_help_buttons:
        row.operator("speedretopo.help_reference_object", icon='HELP')

def ui_decimate(self,context,layout,addonPref,icons,buttons_size,spg,reference_nbf,obj):

    self.huge_faces = False
    if context.object.mode == "OBJECT":
        for obj in context.selected_objects:
            if len(obj.data.polygons) > reference_nbf:
                self.huge_faces = True

    # FACE/TRI Count
    current_mod_state = spg.get_modifiers_state(obj)
    if obj.name != spg.selected_name or current_mod_state != spg.last_mod_state:
        spg.selected_name = obj.name
        spg.last_mod_state = current_mod_state
        spg.update_mesh_info(obj)

    formatted_faces = f"Faces: {spg.face_count:,}"
    formatted_triangles = f"Tris: {spg.triangle_count:,}"

    if addonPref.show_polycount:
        if spg.face_count > reference_nbf:
            box = layout.box()
            row = box.row(align=True)
            row.alert = True
            row.operator("object.speedretopo_tooltip_number_faces", text=f"{formatted_faces}   {formatted_triangles}",
                         icon='ERROR', emboss=False)
        else:
            box = layout.box()
            row = box.row(align=True)
            row.operator("object.speedretopo_tooltip_number_faces", text=f"{formatted_faces}   {formatted_triangles}",
                         emboss=False)

    if self.huge_faces:
        decimate = next((mod for mod in obj.modifiers if mod.type == 'DECIMATE'), None)
        if not decimate:
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_decimate")
            row.operator("object.speedretopo_decimate", text="Decimate", icon_value=icon.icon_id)
            if addonPref.show_help_buttons:
                row.operator("speedretopo.help_decimate", icon='HELP')
        else:
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.3
            # icon = icons.get("icon_valid")
            row.operator("object.speedretopo_apply_decimate", text="Apply Decimate", icon='CHECKMARK')
            row.prop(decimate, "show_viewport", text="", icon='RESTRICT_VIEW_ON')
            row.operator("object.speedretopo_remove_decimate", text="", icon='X')
            if addonPref.show_help_buttons:
                row.operator("speedretopo.help_decimate", icon='HELP')
            row = box.row(align=True)
            row.prop(spg, "edit_decimate", text="Ratio")
            if not addonPref.show_polycount:
                if spg.face_count > reference_nbf:
                    row = box.row(align=True)
                    row.alert = True
                    row.operator("object.speedretopo_tooltip_number_faces",
                                 text=f"{formatted_faces}   {formatted_triangles}", icon='ERROR', emboss=False)
                else:
                    row = box.row(align=True)
                    row.operator("object.speedretopo_tooltip_number_faces",
                                 text=f"{formatted_faces}   {formatted_triangles}", emboss=False)

def ui_retopo(self,context,layout,buttons_size,addonPref,icons,spg,use_color_shader):
    box = layout.box()
    split = box.split()
    col = split.column(align=True)
    row = col.row(align=True)

    row.scale_y = buttons_size + 0.5
    icon = icons.get("icon_speedretopo")
    row.operator("object.speedretopo_create_retopo", text="START RETOPO", icon_value=icon.icon_id)
    row.scale_x = 1.2
    icon = icons.get("icon_settings")
    row.prop(spg, "show_retopo_settings", text="", icon_value=icon.icon_id)

    if addonPref.show_help_buttons:
        row.operator("speedretopo.help_start_retopo", icon='HELP')

    if spg.show_retopo_settings:
        row = col.row(align=True)
        row.separator()
        row = col.row()
        row.scale_y = buttons_size
        row.prop(addonPref, "start_from", text="Tool")

        if addonPref.start_from == 'FACE':
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.label(text="Face Scale")
            row.prop(addonPref, "face_scale", text="")

        row = col.row(align=True)
        row.prop(addonPref, "auto_add_mirror", text="Add Mirror Modifier")

        if not addonPref.start_from == 'POLYBUILD':
            row = col.row(align=True)
            row.prop(addonPref, "auto_add_shrinkwrap", text="Add Shrinkwrap Modifier")

        row = col.row(align=True)
        row.prop(addonPref, "smooth_shading", text="Use Smooth Shading")

        row = col.row(align=True)
        row.prop(addonPref, "use_in_front", text="Use In front")

        row = col.row(align=True)
        row.prop(addonPref, "use_wireframe", text="Show Wireframe")

        row = col.row(align=True)
        row.prop(addonPref, "retopology_shading", text="Retopology Shading")

        if not addonPref.retopology_shading:
            row = col.row(align=True)
            row.prop(addonPref, "use_color_shader", text="Use Color")
            if use_color_shader:
                row.scale_y = buttons_size
                row.prop(addonPref, "obj_color", text="")

        row = col.row()
        row.scale_y = buttons_size
        row.operator("wm.save_userpref", text="Save as Preferences", icon='PREFERENCES')

def ui_modifiers(self,context,obj,layout,addonPref,icons,buttons_size,spg):
    box = layout.box()
    split = box.split()
    col = split.column(align=True)
    row = col.row(align=True)
    if addonPref.show_modifiers_menu:
        icon = icons.get("icon_arrow_down")
    else:
        icon = icons.get("icon_modifiers")
    row.prop(addonPref, "show_modifiers_menu", text="MODIFIERS", icon_value=icon.icon_id, emboss=False)

    if addonPref.show_help_buttons:
        row.operator("speedretopo.help_modifiers", icon='HELP')
    if addonPref.show_modifiers_menu:
        box = layout.box()
        split = box.split()
        col = split.column(align=True)

        # MIRROR
        mirror = next((mod for mod in obj.modifiers if mod.type == 'MIRROR'), None)
        if mirror:
            row = col.row(align=True)
            row.scale_y = buttons_size
            row.scale_x = 1.2
            if mirror.show_viewport == False:
                row.prop(mirror, "show_viewport", text="Mirror")
            elif mirror.show_viewport == True:
                row.prop(mirror, "show_viewport", text="Mirror")
            icon = icons.get("icon_clipping")
            row.prop(mirror, "use_clip", text="", icon_value=icon.icon_id)
            row.prop(mirror, "use_mirror_merge", text="", icon='AUTOMERGE_OFF',
                     toggle=True)
            row.operator("object.speedretopo_apply_mirror", text="", icon='CHECKMARK')
            row.operator("object.speedretopo_remove_mirror", text="", icon='PANEL_CLOSE')
            row = col.row(align=True)
            row.prop(mirror, "merge_threshold", text="Merge Threshold")
        else:
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_mirror")
            row.operator("object.speedretopo_add_mirror", text="Add Mirror", icon_value=icon.icon_id)

        row = col.row(align=True)
        row.separator()

        # shrinkwrap
        if spg.ref_object is not None:
            shrinkwrap = next((mod for mod in obj.modifiers if mod.type == 'SHRINKWRAP'), None)
            if shrinkwrap:
                row = col.row(align=True)
                row.scale_y = buttons_size
                row.scale_x = 1.2
                if shrinkwrap.show_viewport == False:
                    row.prop(shrinkwrap, "show_viewport", text="Shrinkwrap")
                elif shrinkwrap.show_viewport == True:
                    row.prop(shrinkwrap, "show_viewport", text="Shrinkwrap")
                icon = icons.get("icon_update")
                row.operator("object.speedretopo_update_shrinkwrap", text="", icon_value=icon.icon_id)
                row.operator("object.speedretopo_apply_shrinkwrap", text="", icon='CHECKMARK')
                row.operator("object.speedretopo_remove_shrinkwrap", text="", icon='PANEL_CLOSE')
                row = col.row(align=True)
                row.prop(shrinkwrap, "offset", text="Shrinkwrap Offset")

            else:
                row = col.row(align=True)
                row.scale_y = buttons_size
                icon = icons.get("icon_shrinkwrap")
                row.operator("object.speedretopo_add_shrinkwrap", text="Add shrinkwrap", icon_value=icon.icon_id)

            row = col.row(align=True)
            row.separator()

        # Subsurf
        subsurf = next((mod for mod in obj.modifiers if mod.type == 'SUBSURF'), None)
        if subsurf:
            row = col.row(align=True)
            row.scale_y = buttons_size
            row.scale_x = 1.2
            if subsurf.show_viewport == False:
                row.prop(subsurf, "show_viewport", text="Subsurf")
            elif subsurf.show_viewport == True:
                row.prop(subsurf, "show_viewport", text="Subsurf")
            icon = icons.get("icon_optimal_display")
            row.prop(subsurf, "show_only_control_edges", text="",
                     icon_value=icon.icon_id)
            row.prop(subsurf, "show_in_editmode", text="", icon='EDITMODE_HLT')
            row.operator("object.speedretopo_apply_subsurf", text="", icon='CHECKMARK')
            row.operator("object.speedretopo_remove_subsurf", text="", icon='PANEL_CLOSE')
            row = col.row(align=True)
            row.prop(subsurf, "levels", text="Levels")
        else:
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_subsurf")
            row.operator("object.speedretopo_add_subsurf", text="Add Subsurf", icon_value=icon.icon_id)

def ui_tools(self,context,layout,addonPref,icons,buttons_size):
    self.has_mirror = False
    for mod in context.object.modifiers:
        if mod.type == 'MIRROR':
            self.has_mirror = True

    box = layout.box()
    split = box.split()
    col = split.column(align=True)
    row = col.row(align=True)
    if addonPref.show_tools_menu:
        icon = icons.get("icon_arrow_down")
    else:
        icon = icons.get("icon_tools")
    row.prop(addonPref, "show_tools_menu", text="TOOLS", icon_value=icon.icon_id, emboss=False)
    if addonPref.show_help_buttons:
        row.operator("speedretopo.help_tools", icon='HELP')
    if addonPref.show_tools_menu:
        current_brush = context.tool_settings.sculpt.brush
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        if context.object.mode in {'OBJECT', 'SCULPT'}:
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_recalculate_normals_outside")
            row.operator("object.speedretopo_recalculate_normals_outside", text="Recalculate Normals Outside",
                         icon_value=icon.icon_id)
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_recalculate_normals_inside")
            row.operator("object.speedretopo_recalculate_normals_inside", text="Recalculate Normals Inside",
                         icon_value=icon.icon_id)

            # SCULPT BRUSHES
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            icon = icons.get("icon_deform")
            row.scale_x = 1.6
            row.scale_y = buttons_size + 0.3
            row.operator("object.speedretopo_set_deform_brush", text="Deform", icon_value=icon.icon_id)
            if context.object.mode == 'SCULPT':
                if current_brush and current_brush.name == 'Elastic Deform':
                    row.scale_x = 0.4
                    row.prop(current_brush, 'use_automasking_boundary_edges', text='B', toggle=True)

            row = col.row(align=True)
            icon = icons.get("icon_smooth")
            row.scale_x = 1.6
            row.scale_y = buttons_size + 0.3
            row.operator("object.speedretopo_set_smooth_brush", text="Smooth", icon_value=icon.icon_id)
            if context.object.mode == 'SCULPT':
                if current_brush and current_brush.name == 'Smooth':
                    row.scale_x = 0.4
                    row.prop(current_brush, 'use_automasking_boundary_edges', text='B', toggle=True)

            # SYMMETRIZE
            if not self.has_mirror:
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.scale_y = buttons_size + 0.3
                icon = icons.get("icon_mirror")
                row.operator("object.speedretopo_symmetrize", text="Symmetrize", icon_value=icon.icon_id)

        elif context.object.mode == "EDIT":
            row = col.row(align=True)
            if is_bsurface_activated():
                row.scale_y = buttons_size + 0.3
                if context.scene.bsurfaces.SURFSK_mesh == bpy.data.objects[context.object.name]:
                    icon = icons.get("icon_bsurface")
                    row.operator("mesh.surfsk_add_surface", text="Add BSurface", icon_value=icon.icon_id)
                else:
                    icon = icons.get("icon_error")
                    row.operator("object.speedretopo_set_bsurface", text="Click To Set Bsurface Mesh",
                                icon_value=icon.icon_id)
            else:
                row.scale_y = 1.3
                row.alert = True
                # row.operator("object.speedreto_set_bsurface_info",text="Install or Active Bsurface", icon='ERROR')
                row.operator("object.speedretopo_help_install_bsurfaces",text="Install or Active Bsurface", icon='ERROR')

            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_y = buttons_size + 0.3
            icon = icons.get("icon_align_to_x")
            row.operator("object.speedretopo_align_center_edges", text="Align Vertices to Center",icon_value=icon.icon_id)

            if hasattr(bpy.types, "MESH_OT_retopomt"):
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.scale_y = buttons_size
                icon = icons.get("icon_retopomt")
                row.operator("mesh.retopomt", icon_value=icon.icon_id)

            row = col.row(align=True)
            row.separator()
            if is_looptools_activated():
                row = col.row(align=True)
                row.alert = False
                row.scale_y = buttons_size
                icon = icons.get("icon_space")
                row.operator("object.speedretopo_space_relax", text="Space", icon_value=icon.icon_id)
            else:
                row = col.row(align=True)
                row.alert = True
                # row.operator("object.speedreto_set_looptools_info", text="Looptools",icon='ERROR')
                row.operator("speedretopo.help_install_looptools", text="Looptools",icon='ERROR')

                
            row.alert = False
            row.scale_y = buttons_size
            icon = icons.get("icon_relax")
            row.operator("mesh.speedretopo_relax", text="Relax", icon_value=icon.icon_id)

            if is_looptools_activated():
                row = col.row(align=True)
                row.alert = False
                row.scale_y = buttons_size
                icon = icons.get("icon_gstretch")
                row.operator("object.speedretopo_gstretch", text="GStretch", icon_value=icon.icon_id)
                row.scale_y = buttons_size
                icon = icons.get("icon_curve")
                row.operator("mesh.looptools_curve", text="Curve", icon_value=icon.icon_id)
            else:
                row = col.row(align=True)
                row.alert = True
                # row.operator("object.speedreto_set_looptools_info", text="Looptools",icon='ERROR')
                row.operator("speedretopo.help_install_looptools", text="Looptools",icon='ERROR')
                row.alert = True
                # row.operator("object.speedreto_set_looptools_info", text="Looptools",icon='ERROR')
                row.operator("speedretopo.help_install_looptools", text="Looptools",icon='ERROR')
            
            if is_looptools_activated():
                row = col.row(align=True)
                row.scale_y = buttons_size
                icon = icons.get("icon_bridge")
                row.operator("mesh.looptools_bridge", text="Bridge", icon_value=icon.icon_id)
            else:
                row = col.row(align=True)
                row.alert = True
                # row.operator("object.speedreto_set_looptools_info", text="Looptools",icon='ERROR')
                row.operator("speedretopo.help_install_looptools", text="Looptools",icon='ERROR')
            
            row.alert = False
            row.scale_y = buttons_size
            icon = icons.get("icon_gridfill")
            row.operator("mesh.fill_grid", text="Grid Fill", icon_value=icon.icon_id)
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            icon = icons.get("icon_remove_double")
            row.operator("mesh.remove_doubles", text="Remove Double", icon_value=icon.icon_id)
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_recalculate_normals_outside")
            row.operator("object.speedretopo_recalculate_normals_outside", text="Recalculate Normals Outside",
                         icon_value=icon.icon_id)
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_recalculate_normals_inside")
            row.operator("object.speedretopo_recalculate_normals_inside", text="Recalculate Normals Inside",
                         icon_value=icon.icon_id)
            row = col.row(align=True)
            row.scale_y = buttons_size
            icon = icons.get("icon_flip_normals")
            row.operator("mesh.flip_normals", text="Flip Normals", icon_value=icon.icon_id)
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            row.scale_y = buttons_size
            row.operator("object.speedretopo_symmetrize", text="Symmetrize", icon='MOD_MIRROR')
            row = col.row(align=True)
            row.separator()

            # AUTO MERGE
            row = col.row(align=True)
            row.scale_y = buttons_size
            row.prop(context.tool_settings, "use_mesh_automerge", text="Auto Merge")
            if context.scene.tool_settings.use_mesh_automerge:
                row = col.row(align=True)
                row.scale_y = buttons_size
                row.prop(context.tool_settings, "double_threshold", text="Threshold")
                row = col.row(align=True)
                row.scale_y = buttons_size
                row.operator("object.speedretopo_double_threshold_minus", text="0.001")
                row.operator("object.speedretopo_double_threshold_plus", text="0.1")

            # SCULPT BRUSHES
            row = col.row(align=True)
            row.separator()
            row = col.row(align=True)
            icon = icons.get("icon_deform")
            row.scale_x = 1.6
            row.scale_y = buttons_size + 0.3
            row.operator("object.speedretopo_set_deform_brush", text="Deform", icon_value=icon.icon_id)
            if context.object.mode == 'SCULPT':
                if current_brush and current_brush.name == 'Elastic Deform':
                    row.scale_x = 0.4
                    row.prop(current_brush, 'use_automasking_boundary_edges', text='B', toggle=True)

            row = col.row(align=True)
            icon = icons.get("icon_smooth")
            row.scale_x = 1.6
            row.scale_y = buttons_size + 0.3
            row.operator("object.speedretopo_set_smooth_brush", text="Smooth", icon_value=icon.icon_id)
            if context.object.mode == 'SCULPT':
                if current_brush and current_brush.name == 'Smooth':
                    row.scale_x = 0.4
                    row.prop(current_brush, 'use_automasking_boundary_edges', text='B', toggle=True)

            # CENTER TOOLS
            box = layout.box()
            split = box.split()
            col = split.column(align=True)
            if addonPref.show_center_tools:
                icon = icons.get("icon_arrow_down")
            else:
                icon = icons.get("icon_center")
            col.prop(addonPref, "show_center_tools", text="CENTER TOOLS", icon_value=icon.icon_id)
            if addonPref.show_center_tools:
                row = col.row(align=True)

                me = context.object.data
                bm = bmesh.from_edit_mesh(me)
                if [v for v in bm.verts if v.select]:
                    row.operator("object.speedretopo_set_unset_center", text='Set',
                                 icon='LAYER_ACTIVE').set_unset_center = "set"
                    row.operator("object.speedretopo_set_unset_center", text='UnSet',
                                 icon='IPO_LINEAR').set_unset_center = "unset"
                row = col.row(align=True)
                row.operator("object.speedretopo_set_unset_center", text='Select',
                             icon='GROUP_VERTEX').set_unset_center = "select"
                row.operator("object.speedretopo_set_unset_center", text='Clear',
                             icon='SELECT_SET').set_unset_center = "clear"

            # FREEZING
            box = layout.box()
            split = box.split()
            col = split.column(align=True)
            if addonPref.show_freeze_unfreeze:
                icon = icons.get("icon_arrow_down")
            else:
                icon = icons.get("icon_freeze")
            col.prop(addonPref, "show_freeze_unfreeze", text="FREEZING TOOLS", icon_value=icon.icon_id)
            if addonPref.show_freeze_unfreeze:

                row = col.row(align=True)

                me = context.object.data
                bm = bmesh.from_edit_mesh(me)
                if [v for v in bm.verts if v.select]:
                    row.operator("object.speedretopo_freeze_unfreeze", text='Freeze',
                                 icon='FREEZE').freeze_unfreeze = "freeze"
                    row.operator("object.speedretopo_freeze_unfreeze", text='UnFreeze',
                                 icon='IPO_LINEAR').freeze_unfreeze = "unfreeze"
                row = col.row(align=True)
                row.operator("object.speedretopo_freeze_unfreeze", text='Select',
                             icon='GROUP_VERTEX').freeze_unfreeze = "select"
                row.operator("object.speedretopo_freeze_unfreeze", text='Clear',
                             icon='SELECT_SET').freeze_unfreeze = "clear"

def ui_shading(self, context,layout,obj,spg,buttons_size,icons,addonPref,overlay,shading):
    box = layout.box()
    split = box.split()
    col = split.column(align=True)
    row = col.row(align=True)
    if addonPref.show_shading_menu:
        icon = icons.get("icon_arrow_down")
    else:
        icon = icons.get("icon_shading")
    row.prop(addonPref, "show_shading_menu", text="SHADING",
             icon_value=icon.icon_id, emboss=False)
    if addonPref.show_help_buttons:
        row.operator("speedretopo.help_shading", icon='HELP')

    if addonPref.show_shading_menu:
        box = layout.box()
        split = box.split()
        col = split.column(align=True)

        row = col.row(align=True)
        row.operator("object.speedretopo_set_smooth", text="Smooth Shading", icon='SHADING_RENDERED')
        row = col.row(align=True)
        row.operator("object.speedretopo_set_flat", text="Flat Shading", icon='SHADING_WIRE')

        row = col.row(align=True)
        row.scale_y = buttons_size
        row.prop(obj, "show_in_front", text="In Front", icon='CHECKBOX_HLT' if obj.show_in_front else 'CHECKBOX_DEHLT')

        row = col.row(align=True)
        row.scale_y = buttons_size
        row.prop(obj, "show_wire", text="Object Wireframe", icon='CHECKBOX_HLT' if obj.show_wire else 'CHECKBOX_DEHLT')

        row = col.row(align=True)
        row.scale_y = buttons_size
        row.prop(shading, "show_backface_culling", text="Back Face Culling",
                 icon='CHECKBOX_HLT' if shading.show_backface_culling else 'CHECKBOX_DEHLT')

        if context.object.mode == "EDIT":
            row = col.row(align=True)
            row.scale_y = buttons_size
            row.prop(overlay, "show_fade_inactive", text="Fade Inactive",
                     icon='CHECKBOX_HLT' if overlay.show_fade_inactive else 'CHECKBOX_DEHLT')

            if overlay.show_fade_inactive:
                row = col.row(align=True)
                row.prop(overlay, "fade_inactive_alpha", text="")

            row = col.row(align=True)
            row.scale_y = buttons_size
            if bpy.app.version < (3, 6, 0):
                row.prop(overlay, "show_occlude_wire", text="Hidden Wire",
                         icon='CHECKBOX_HLT' if overlay.show_occlude_wire else 'CHECKBOX_DEHLT')
            else:
                row.prop(overlay, "show_retopology", text="Retopology Shading",
                         icon='CHECKBOX_HLT' if overlay.show_retopology else 'CHECKBOX_DEHLT')
                if overlay.show_retopology:
                    row = col.row(align=True)
                    row.scale_y = buttons_size
                    row.prop(overlay, "retopology_offset")

        if not context.space_data.overlay.show_retopology:
            if context.object.type in {'MESH', 'META', 'FONT', 'CURVE', 'CURVES', 'SURFACE', 'GPENCIL'}:
                row = col.row()
                row.separator()
                row = col.row(align=True)
                row.scale_y = buttons_size
                row.scale_x = 1.5
                row.prop(spg, 'transparency', text="Transparency", slider=True)
                row.scale_x = 0.25
                row.prop(spg, "obj_color", text="")
                row.scale_x = 1.2
                row.operator("object.speedretopo_reverse_alpha", text="", icon='ARROW_LEFTRIGHT')
                row.operator("object.speedretopo_remove_alpha", text="", icon='X')

def SpeedRetopo(self, context):

    layout = self.layout
    tool_settings = context.tool_settings
    overlay = context.space_data.overlay
    shading = context.space_data.shading
    addonPref = get_addon_preferences()
    use_color_shader = addonPref.use_color_shader
    buttons_size = addonPref.buttons_size
    icons = load_icons()
    reference_nbf = addonPref.reference_nbf
    spg = context.window_manager.speedretopo_PropertyGroup
    obj = context.active_object

    ui_decimate(self,context,layout,addonPref,icons,buttons_size,spg,reference_nbf,obj)

    # REF object
    if obj and obj.name != spg.selected_name:
        spg.selected_name = obj.name
        if "ref_obj" in obj:
            ref_obj_name = obj["ref_obj"]
            ref_obj = bpy.data.objects.get(ref_obj_name)
            if ref_obj:
                spg.ref_object = ref_obj
        else:
            spg.ref_object = None

    ui_ref_object(self,context,layout,obj,buttons_size,spg,icons,addonPref)

    if context.object.mode == "OBJECT" and  context.object.mode in {'OBJECT', 'SCULPT'}:
        ui_retopo(self,context,layout,buttons_size,addonPref,icons,spg,use_color_shader)

    # MODIFIERS
    if context.object.mode in {'OBJECT','EDIT', 'SCULPT'}:
        ui_modifiers(self, context, obj, layout, addonPref, icons, buttons_size,spg)

    # TOOLS
    ui_tools(self,context,layout,addonPref,icons,buttons_size)

    # SHADING
    ui_shading(self, context,layout,obj,spg,buttons_size,icons,addonPref,overlay,shading)

class SPEEDRETOPO_PT_start_retopo_settings(bpy.types.Operator):
    bl_idname = "view3d.start_retopo_settings"
    bl_label = "Start Retopo Settings"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.object.mode == "OBJECT"

    def invoke(self, context, event):
        self.dpi_value = context.preferences.system.dpi
        context.window_manager.windows[0].cursor_warp(x=int(event.mouse_x - 125), y=event.mouse_y + 100)
        popup = context.window_manager.invoke_popup(self, width=200)
        context.window_manager.windows[0].cursor_warp(x=event.mouse_x, y=event.mouse_y)
        return popup

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        addonPref = get_addon_preferences()
        use_color_shader = addonPref.use_color_shader
        obj = context.active_object
        spg = context.window_manager.speedretopo_PropertyGroup
        buttons_size = addonPref.buttons_size

        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.label(text="REFERENCE OBJECT")
        row = col.row(align=True)
        row.scale_y = buttons_size
        row.prop(spg, "ref_object", text="", icon='MESH_MONKEY')

        if addonPref.show_help_buttons:
            row.operator("speedretopo.help_reference_object", icon='HELP')

        if context.object.mode == "OBJECT" and context.object.mode in {'OBJECT', 'SCULPT'}:
            box = layout.box()
            split = box.split()
            col = split.column(align=True)
            row = col.row(align=True)

            row.scale_y = buttons_size + 0.5
            icon = icons.get("icon_speedretopo")
            row.operator("object.speedretopo_create_retopo", text="START RETOPO", icon_value=icon.icon_id)
            row.scale_x = 1.2
            icon = icons.get("icon_settings")
            row.prop(spg, "show_retopo_settings", text="", icon_value=icon.icon_id)

            if addonPref.show_help_buttons:
                row.operator("speedretopo.help_start_retopo", icon='HELP')

            if spg.show_retopo_settings:
                row = col.row(align=True)
                row.separator()
                row = col.row()
                row.scale_y = buttons_size
                row.prop(addonPref, "start_from", text="Tool")

                if addonPref.start_from == 'FACE':
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.label(text="Face Scale")
                    row.prop(addonPref, "face_scale", text="")

                row = col.row(align=True)
                row.prop(addonPref, "auto_add_mirror", text="Add Mirror Modifier")

                if not addonPref.start_from == 'POLYBUILD':
                    row = col.row(align=True)
                    row.prop(addonPref, "auto_add_shrinkwrap", text="Add Shrinkwrap Modifier")

                row = col.row(align=True)
                row.prop(addonPref, "smooth_shading", text="Use Smooth Shading")

                row = col.row(align=True)
                row.prop(addonPref, "use_in_front", text="Use In front")

                row = col.row(align=True)
                row.prop(addonPref, "use_wireframe", text="Show Wireframe")

                row = col.row(align=True)
                row.prop(addonPref, "retopology_shading", text="Retopology Shading")

                if not addonPref.retopology_shading:
                    row = col.row(align=True)
                    row.prop(addonPref, "use_color_shader", text="Use Color")
                    if use_color_shader:
                        row.scale_y = buttons_size
                        row.prop(addonPref, "obj_color", text="")

                row = col.row()
                row.scale_y = buttons_size
                row.operator("wm.save_userpref", text="Save as Preferences", icon='PREFERENCES')

class SPEEDRETOPO_PT_popup_menu(bpy.types.Operator):
    bl_idname = "view3d.speedretopo_popup_menu"
    bl_label = "Edit Menu"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    @classmethod
    def poll(cls, context):
        return len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH']) == 1

    def invoke(self, context, event):
        context.window_manager.windows[0].cursor_warp(x=int(event.mouse_x - 130), y=event.mouse_y + 100)
        popup = context.window_manager.invoke_popup(self, width=200)
        context.window_manager.windows[0].cursor_warp(x=event.mouse_x, y=event.mouse_y)
        return popup

    def draw(self, context):
        layout = self.layout

        SpeedRetopo(self, context)

class SPEEDRETOPO_OT_start_or_edit(bpy.types.Operator):
    bl_idname = 'object.speedretopo_ot_start_or_edit'
    bl_label = "Speedretopo"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH']) == 1


    def execute(self, context):
        addonPref = get_addon_preferences()
        use_menu_or_pie_menu = addonPref.use_menu_or_pie_menu
        spg = context.window_manager.speedretopo_PropertyGroup
        obj = context.active_object

        if context.object.mode == 'EDIT':
            if use_menu_or_pie_menu == 'menu':
                bpy.ops.view3d.speedretopo_popup_menu('INVOKE_DEFAULT')
            else:
                bpy.ops.wm.call_menu_pie('INVOKE_DEFAULT', name="SPEEDRETOPO_MT_pie_menu")

        # elif context.object.mode not in {'EDIT','SCULPT'}:
        elif context.object.mode != 'EDIT':
            if obj.get("ref_obj") and spg.ref_object is not None:
                bpy.ops.object.mode_set(mode='EDIT')
                if use_menu_or_pie_menu == 'menu':
                    bpy.ops.view3d.speedretopo_popup_menu('INVOKE_DEFAULT')
                else:
                    bpy.ops.wm.call_menu_pie('INVOKE_DEFAULT', name="SPEEDRETOPO_MT_pie_menu")

                bpy.ops.object.speedretopo_set_bsurface()

                if addonPref.smooth_shading:
                    # bpy.ops.object.shade_smooth()
                    if is_bsurface_activated():
                        context.scene.bsurfaces.SURFSK_shade_smooth = True

            else:
                bpy.ops.view3d.start_retopo_settings('INVOKE_DEFAULT')

        elif context.object.mode == 'SCULPT':
            if obj.get("ref_obj") and spg.ref_object is not None:
                if use_menu_or_pie_menu == 'menu':
                    bpy.ops.view3d.speedretopo_popup_menu('INVOKE_DEFAULT')
                else:
                    bpy.ops.wm.call_menu_pie('INVOKE_DEFAULT', name="SPEEDRETOPO_MT_pie_menu")

                bpy.ops.object.speedretopo_set_bsurface()

            else:
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.view3d.start_retopo_settings('INVOKE_DEFAULT')

        return {'FINISHED'}

def is_boundary_loop(edges):
    # Count the number of selected edges connected to each vertex
    vertex_counts = {}
    for edge in edges:
        for vert in edge.verts:
            if vert not in vertex_counts:
                vertex_counts[vert] = 0
            vertex_counts[vert] += 1

    # If we have any vertices connected to more than two selected edges (a branch)
    # or only one selected edge (a dead end), it's not a loop
    for count in vertex_counts.values():
        if count != 2:
            return False

    # If we made it this far, check if all edges are boundary edges
    return all(e.is_boundary for e in edges)

# class SPEEDRETOPO_OT_set_bsurface_info(Operator):
#     bl_idname = 'object.speedreto_set_bsurface_info'
#     bl_label = "Set Bsurface Info"
#     bl_description = "Install or Activate Bsurface to use it with Speedretopo"
#     bl_options = {'REGISTER','UNDO'}

#     def execute(self, context):
#         return {'FINISHED'}

# class SPEEDRETOPO_OT_set_looptools_info(Operator):
#     bl_idname = 'object.speedreto_set_looptools_info'
#     bl_label = "Set Looptools Info"
#     bl_description = "Install or Activate Looptools to use it with Speedretopo"
#     bl_options = {'REGISTER','UNDO'}

#     def execute(self, context):
#         return {'FINISHED'}

class SPEEDRETOPO_MT_pie_menu(Menu):
    bl_label = "SPEEDRETOPO"

    @classmethod
    def poll(cls, context):
        return len(context.object is not None and context.selected_objects) == 1

    def draw(self, context):
        pie = self.layout.menu_pie()
        icons = load_icons()
        me = context.object.data
        bm = bmesh.from_edit_mesh(me)
        selected_verts = [v for v in bm.verts if v.select]
        selected_edges = [e for e in bm.edges if e.select]
        selected_faces = [f for f in bm.faces if f.select]
        obj = context.active_object
        addonPref = get_addon_preferences()

        # 4 - LEFT
        if selected_edges and is_boundary_loop(selected_edges):
            icon = icons.get("icon_gridfill")
            pie.operator("mesh.fill_grid", text="Grid Fill", icon_value=icon.icon_id)
        else:
            # BRIDGE
            if len(selected_edges) >= 2:
                if is_looptools_activated():
                    icon = icons.get("icon_bridge")
                    pie.operator("mesh.bridge_edge_loops", text="Bridge", icon_value=icon.icon_id)
                else:
                    row = pie.row()
                    row.alert = True
                    row.scale_y = 1.5
                    # row.operator("object.speedreto_set_looptools_info", text="Install or Active Looptools",icon="ERROR")
                    row.operator("speedretopo.help_install_looptools", text="Install or Active Looptools",icon='ERROR')
            else:
                pie.separator()

        #6 - RIGHT
        if any([selected_verts, selected_edges]):
            icon = icons.get("icon_align_to_x")
            pie.operator("object.speedretopo_align_center_edges", text="Align to Center", icon_value=icon.icon_id)
        else:
            icon = icons.get("icon_recalculate_normals_outside")
            pie.operator("object.speedretopo_recalculate_normals_outside", text="Normals Outside", icon_value=icon.icon_id)

        #2 - BOTTOM
        icon = icons.get("icon_smooth")
        pie.operator("object.speedretopo_set_smooth_brush", text="Smooth Brush", icon_value=icon.icon_id)

        #8 - TOP
        if selected_verts or len(obj.data.vertices) == 0:
            if is_bsurface_activated():
                if context.scene.bsurfaces.SURFSK_mesh == bpy.data.objects[context.object.name]:
                    icon = icons.get("icon_bsurface")
                    pie.operator("mesh.surfsk_add_surface", text="Add BSurface", icon_value=icon.icon_id)
                else:
                    icon = icons.get("icon_error")
                    pie.operator("object.speedretopo_set_bsurface", text="Click To Set Bsurface Mesh",
                                icon_value=icon.icon_id)
            else:
                row = pie.row()
                row.alert = True
                row.scale_y = 1.5
                # row.operator("object.speedreto_set_bsurface_info",text="Install or Active Bsurface", icon='ERROR')
                row.operator("object.speedretopo_help_install_bsurfaces",text="Install or Active Bsurface", icon='ERROR')

        else:
            pie.separator()

        #7 - TOP - LEFT
        shrinkwrap = context.object.modifiers.get("Shrinkwrap")
        if shrinkwrap:
            icon = icons.get("icon_update")
            pie.operator("object.speedretopo_update_shrinkwrap", text="Update Shrinkwrap", icon_value=icon.icon_id)
        else:
            pie.operator("object.speedretopo_add_shrinkwrap", text="Add Shrinkwrap", icon='MOD_SHRINKWRAP')

        #9 - TOP - RIGHT
        if any([selected_verts, selected_edges]):
            if len(selected_verts) >= 2:
                if is_looptools_activated():
                    icon = icons.get("icon_space")
                    pie.operator("object.speedretopo_space_relax", text="Space", icon_value=icon.icon_id)
                else:
                    row = pie.row()
                    row.alert = True
                    row.scale_y = 1.5
                    # row.operator("object.speedreto_set_looptools_info", text="Install or Active Looptools",icon='ERROR')
                    row.operator("speedretopo.help_install_looptools", text="Install or Active Looptools",icon='ERROR')
            else:
                pie.separator()
        else:
            icon = icons.get("icon_recalculate_normals_inside")
            pie.operator("object.speedretopo_recalculate_normals_inside", text="Normals Inside",
                         icon_value=icon.icon_id)

        #1 - BOTTOM - LEFT
        icon = icons.get("icon_deform")
        pie.operator("object.speedretopo_set_deform_brush", text="Deform Brush", icon_value=icon.icon_id)


        #3 - BOTTOM - RIGHT
        icon = icons.get("icon_relax")
        pie.operator("mesh.speedretopo_relax", text="Relax", icon_value=icon.icon_id)

# -----------------------------------------------------------------------------
#    Help
# -----------------------------------------------------------------------------
class SPEEDRETOPO_MT_help_install_looptools(bpy.types.Operator):
    bl_idname = "speedretopo.help_install_looptools"
    bl_label = ""
    bl_description = ("To use Looptools, you need ton install it\n\n"
                      "- Open Blender Preferences\n"
                      "- Go to the System Tab\n"
                      "- In Network Tab, click on Allow Online Access\n"
                      "- Go to the Get Extentions Tab\n"
                      "- Search For Looptools\n"
                      "- Click on Install\n\n"
                      "Click to see a Video tutorial\n")

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        layout.label(text="To use LoopTools, you need ton install it")
        layout.label(text="- Open Blender Preferences")
        layout.label(text="- Go to the System Tab")
        layout.label(text="- In Network Tab, click on Allow Online Access")
        layout.label(text="- Go to the Get Extentions Tab")
        layout.label(text="- Search For Looptool")
        layout.label(text="- Click on Install")

        icon = icons.get("icon_youtube")
        layout.operator("wm.url_open", text="VIDEO", icon_value=icon.icon_id).url = "https://www.youtube.com/shorts/rsCaVLdyJ6w?feature=share"

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))
    
class SPEEDRETOPO_MT_help_install_bsurfaces(bpy.types.Operator):
    bl_idname = "object.speedretopo_help_install_bsurfaces"
    bl_label = ""
    bl_description = ("To use Bsurfaces, you need ton install it\n\n"
                      "- Open Blender Preferences\n"
                      "- Go to the System Tab\n"
                      "- In Network Tab, click on Allow Online Access\n"
                      "- Go to the Get Extentions Tab\n"
                      "- Search For Bsurfaces\n"
                      "- Click on Install\n\n"
                      "Click to see a Video tutorial\n")
    
    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        layout.label(text="To use Bsurfaces, you need ton install it")
        layout.label(text="- Open Blender Preferences")
        layout.label(text="- Go to the System Tab")
        layout.label(text="- In Network Tab, click on Allow Online Access")
        layout.label(text="- Go to the Get Extentions Tab")
        layout.label(text="- Search For Bsurfaces")
        layout.label(text="- Click on Install")

        icon = icons.get("icon_youtube")
        layout.operator("wm.url_open", text="VIDEO", icon_value=icon.icon_id).url = "https://www.youtube.com/shorts/rsCaVLdyJ6w?feature=share"

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))
    
class SPEEDRETOPO_MT_help_reference_object(bpy.types.Operator):
    bl_idname = "speedretopo.help_reference_object"
    bl_label = ""
    bl_description = "Help Reference Object, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def draw(self, context):
        icons = load_icons()
        layout = self.layout

        layout.label(text="The reference object is connected to your retopo object.")
        layout.label(text="It is used as reference for the modifiers, Mirror and Shrinkwrap.")
        layout.label(text="You can remove it and change it.")

        layout.separator()
        layout.label(text="The addon needs it to use modifiers.", icon='INFO')

        layout.separator()
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_reference_object.mp4"

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

class SPEEDRETOPO_MT_help_start_retopo(bpy.types.Operator):
    bl_idname = "speedretopo.help_start_retopo"
    bl_label = ""
    bl_description = "Help Starting Retopology, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def draw(self, context):

        icons = load_icons()

        layout = self.layout


        layout.label(text="To start your Retopology, you need to select the reference object first.")

        layout.separator()
        layout.label(text="This object will be connected to your Retopo Object.", icon='INFO')

        layout.separator()
        icon = icons.get("icon_decimate")
        layout.label(text="DECIMATE", icon_value=icon.icon_id)
        layout.label(text="If you object has too many vertices, it can decrease performances.")
        layout.label(text="Then, you can Decimate it with the Decimate Modifier.")
        layout.label(text="Click on the button en set the ratio to something lighter.")
        layout.label(text="Once the number of vertices is ok,")
        layout.label(text="click on Apply and start your retopology.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "https://youtu.be/cKhZNOFc4Us?t=2111"

        layout.separator()
        layout.label(text="You will now see a menu to Start the Retopology.")
        layout.operator("wm.url_open", text="IMAGE",
                     icon='IMAGE_DATA').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_001.jpg"
        layout.label(text="You will be able to choose the tool you want to use.")
        layout.operator("wm.url_open", text="IMAGE",
                     icon='IMAGE_DATA').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_002.jpg"

        layout.separator()
        icon = icons.get("icon_bsurface")
        layout.label(text="BSURFACE", icon_value=icon.icon_id)
        layout.label(text="Bsurface is a well known Addon that allows you")
        layout.label(text="to draw lines and create faces on your Retopology.")
        layout.label(text="By pressing D key and draw, you will create lines.")
        layout.label(text="Once your lines are created,")
        layout.label(text="you can press Add Bsurface button in the Menu.")
        layout.label(text="That will create the first faces of your retopology.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "https://youtu.be/cKhZNOFc4Us?t=899"

        layout.separator()
        layout.label(text="Tools so Start")
        layout.operator("wm.url_open", text="VIDEO",
                        icon='FILE_MOVIE').url = "https://youtu.be/cKhZNOFc4Us?t=374"
        layout.separator()
        icon = icons.get("icon_vertex")
        layout.label(text="VERTEX", icon_value=icon.icon_id)
        layout.label(text="That Vertex tool is a simple vertex, as simple as that!")
        layout.label(text="You can place it where you want on your reference mesh.")
        layout.label(text="After that you just have to extrude it")
        layout.label(text="and use normal poly editing tools.")

        layout.separator()
        icon = icons.get("icon_face")
        layout.label(text="FACE", icon_value=icon.icon_id)
        layout.label(text="That Face tool is a simple face that you will be able to place on the surface of your mesh")

        layout.separator()
        icon = icons.get("icon_polybuild")
        layout.label(text="POLYBUILD", icon_value=icon.icon_id)
        layout.label(text="Polybuild is an inside tool from Blender")
        layout.label(text="to help you create and edit your retopology.")
        layout.label(text="It's a several in one tool using shortcuts")
        layout.label(text="to extrude faces and move vertices")

        layout.separator()
        layout.label(text="SpeedRetopo automatize things for you,")
        layout.label(text="it will automatically create modifiers like Mirror and Shrinkwrap.")
        layout.label(text="You just have to start and edit your retopology.")
        layout.separator()
        layout.label(text="So, when you have created your first faces with the tool of you choice,")
        layout.label(text="you will have the edit menu.")
        layout.label(text="With it, you will be able to edit modifiers and your mesh.")


    def invoke(self, context, event):
            dpi_value = bpy.context.preferences.view.ui_scale
            coef = dpi_value * (-175) + 525
            return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

class SPEEDRETOPO_MT_help_modifiers(bpy.types.Operator):
    bl_idname = "speedretopo.help_modifiers"
    bl_label = ""
    bl_description = "Help Modifiers, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def draw(self, context):
        icons = load_icons()
        layout = self.layout

        layout.label(text="You will be able to edit the modifiers.")
        layout.label(text="Apply them, remove them and add them again if necessary.")
        layout.label(text="You will be able to align the center Vertices to .")

        layout.separator()
        icon = icons.get("icon_mirror")
        layout.label(text="MIRROR", icon_value=icon.icon_id)
        layout.label(text="The Mirror Modifiers create a mirror of your object on the X axis.")
        layout.label(text="You can Apply it, remove it, use the clipping setting")
        layout.label(text="to keep the middle vertices at the center of the scene.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_mirror_modifier.mp4"

        layout.separator()
        icon = icons.get("icon_shrinkwrap")
        layout.label(text="SHRINKWRAP", icon_value=icon.icon_id)
        layout.label(text="The Shrinkwrap Modifiers projects your retopology on the surface")
        layout.label(text="of the reference object.")
        layout.label(text="You can Apply it, remove it and update it.")

        layout.separator()
        layout.label(text="This Modifiers needs to be updated regularly to be efficient.", icon='INFO')
        layout.label(text="The modifier auto align to center the vertices", icon='INFO')
        layout.label(text="you have setted as center.")

        layout.separator()
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_shrinkwrap_modifier.mp4"

        layout.separator()
        icon = icons.get("icon_subsurf")
        layout.label(text="SUBSURF", icon_value=icon.icon_id)
        layout.label(text="The Subsurf Modifiers subdivide your surface")
        layout.label(text="it's useful to see if the retopology is correct.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "https://youtu.be/cKhZNOFc4Us?t=2271"

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

class SPEEDRETOPO_MT_help_tools(bpy.types.Operator):
    bl_idname = "speedretopo.help_tools"
    bl_label = ""
    bl_description = "Help Tools, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def draw(self, context):
        icons = load_icons()
        layout = self.layout

        layout.label(text="In Edit Mode you have differents tools.")

        layout.separator()
        icon = icons.get("icon_bsurface")
        layout.label(text="BSURFACE", icon_value=icon.icon_id)
        layout.label(text="Listed previously, allow you to draw lines to create faces.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_bsurface_in_action.mp4"

        layout.separator()
        icon = icons.get("icon_align_to_x")
        layout.label(text="ALING TO X", icon_value=icon.icon_id)
        layout.label(text="Align the center vertices to the center of the scene.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_align_to_x.mp4"

        layout.separator()
        icon = icons.get("icon_retopomt")
        layout.label(text="RETOPO MT", icon_value=icon.icon_id)
        layout.label(text="Special tool for retopology.")

        layout.separator()
        layout.label(text="You need to activate it in the preferences.", icon='INFO')

        layout.separator()
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_retopo_mt.mp4"

        layout.separator()
        icon = icons.get("icon_space")
        layout.label(text="SPACE", icon_value=icon.icon_id)
        layout.label(text="This tool keep the vertices on a loop at the same space.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_space_tool.mp4"

        layout.separator()
        icon = icons.get("icon_relax")
        layout.label(text="RELAX", icon_value=icon.icon_id)
        layout.label(text="Relax the selection to make it better.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_relax_tool.mp4"

        layout.separator()
        icon = icons.get("icon_gstretch")
        layout.label(text="GSTRETCH", icon_value=icon.icon_id)
        layout.label(text="This tool aligns vertices with grease pencil lines.")

        layout.separator()
        layout.label(text="Seems not to work on latest builds of blender.", icon='INFO')

        layout.separator()
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_gstretch_tool.mp4"

        layout.separator()
        icon = icons.get("icon_curve")
        layout.label(text="CURVE", icon_value=icon.icon_id)
        layout.label(text="This tool creates a curve on 3 points selection on a loop.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_curve_tool.mp4"

        layout.separator()
        icon = icons.get("icon_bridge")
        layout.label(text="BRIDGE", icon_value=icon.icon_id)
        layout.label(text="This tool creates faces between too selected loops.")

        layout.separator()
        layout.label(text="Better to have the same amount of vertices.", icon='INFO')

        layout.separator()
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_bridge_tool.mp4"

        layout.separator()
        icon = icons.get("icon_gridfill")
        layout.label(text="GRIDFILL", icon_value=icon.icon_id)
        layout.label(text="This tool creates faces in holes.")
        layout.label(text="you need to select 2 loops with the same number of vertices.")

        layout.separator()
        layout.label(text="Check the looptools documentation to learn more about it.", icon='INFO')

        layout.separator()
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_bridge_tool.mp4"

        layout.separator()
        icon = icons.get("icon_recalculate_normals_outside")
        layout.label(text="RECALCULATE NORMALS", icon_value=icon.icon_id)
        layout.label(text="This tool flips the normals of the mesh Outside or Inside.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_recalculate_normals.mp4"

        layout.separator()
        icon = icons.get("icon_flip_normals")
        layout.label(text="FLIP NORMALS", icon_value=icon.icon_id)
        layout.label(text="This tool flips the normals of the selected faces.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_flip_normals.mp4"

        layout.separator()
        icon = icons.get("icon_center")
        layout.label(text="CENTER TOOLS", icon_value=icon.icon_id)
        layout.label(text="Center tools allows you too set some vertices as center.")
        layout.label(text="That's mean, those vertices will always be at the center of the grid when you will")
        layout.label(text="update the Shrinkwrap modifier.")
        layout.separator()
        layout.label(text="You can set or Unset the selection.")
        layout.label(text="Also Select and clear the entire set to remove all vertices from the set.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_center_tools.mp4"

        layout.separator()
        icon = icons.get("icon_freeze")
        layout.label(text="FREEZING TOOLS", icon_value=icon.icon_id)
        layout.label(text="Freezing tools allows you too freeze some vertices.")
        layout.label(text="That's mean, those vertices will be used for the Shrinkwrap modifier.")
        layout.separator()
        layout.label(text="You can Freeze or Unfreeze the selection.")
        layout.label(text="Also Select and clear the entire set to remove all vertices from the set.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "http://blscripts.com/speedretopo/screenshots/speedretopo_freezing_tools.mp4"

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

class SPEEDRETOPO_MT_help_shading(bpy.types.Operator):
    bl_idname = "speedretopo.help_shading"
    bl_label = ""
    bl_description = "Help Shading, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def draw(self, context):
        icons = load_icons()
        layout = self.layout

        layout.label(text="The shading part help you to better see your retopology")
        layout.label(text="on the reference object.")
        layout.operator("wm.url_open", text="VIDEO",
                     icon='FILE_MOVIE').url = "https://youtu.be/cKhZNOFc4Us?t=1950"

        layout.separator()
        if bpy.app.version < (3, 6, 0):
            layout.label(text="HIDDEN WIRE")
            layout.label(text="Will hide faces to only see the wireframe of your object.")
        else:
            layout.label(text="RETOPOLOGY SHADING")
            layout.label(text="Will make faces transparent to let you see your reference object.")

        layout.separator()
        layout.label(text="IN FRONT")
        layout.label(text="You will always see the retopo object on top of the reference object.")

        layout.separator()
        layout.label(text="WIREFRAME")
        layout.label(text="Will show the wireframe of your object.")

        layout.separator()
        layout.label(text="BACK FACE CULLING")
        layout.label(text="You will see through the back of the faces of your object.")

        layout.separator()
        layout.label(text="COLOR")
        layout.label(text="It will add a color shader with transparency to your object.")
        layout.label(text="You can change the color and remove it.")


    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

class SPEEDRETOPO_MT_help_decimate(bpy.types.Operator):
    bl_idname = "speedretopo.help_decimate"
    bl_label = ""
    bl_description = "Help Decimate, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def draw(self, context):
        icons = load_icons()
        layout = self.layout

        icon = icons.get("icon_decimate")
        layout.label(text="DECIMATE", icon_value=icon.icon_id)
        layout.label(text="If you object has too many vertices, it can decrease performances.")
        layout.label(text="Then, you can Decimate it with the Decimate Modifier.")
        layout.label(text="Click on the button en set the ratio to something lighter.")
        layout.label(text="Once the number of vertices is ok, ")
        layout.label(text="click on Apply and start your retopology.")

        layout.separator()
        layout.label(text="You can change the value that will check the mesh", icon='INFO')
        layout.label(text="in the addon preferences.")

        layout.separator()
        layout.operator("wm.url_open", text="VIDEO",
                        icon='FILE_MOVIE').url = "https://youtu.be/cKhZNOFc4Us?t=2111"

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

CLASSES =  [SPEEDRETOPO_PT_ui,
            SPEEDRETOPO_MT_pie_menu,
            SPEEDRETOPO_OT_start_or_edit,
            SPEEDRETOPO_PT_start_retopo_settings,
            SPEEDRETOPO_PT_popup_menu,
            SPEEDRETOPO_MT_help_start_retopo,
            SPEEDRETOPO_MT_help_reference_object,
            SPEEDRETOPO_MT_help_modifiers,
            SPEEDRETOPO_MT_help_tools,
            SPEEDRETOPO_MT_help_shading,
            SPEEDRETOPO_MT_help_decimate,
            SPEEDRETOPO_OT_tooltip_number_faces,
            SPEEDRETOPO_MT_help_install_bsurfaces,
            SPEEDRETOPO_MT_help_install_looptools,
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")


def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
