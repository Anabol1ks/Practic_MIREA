# -*- coding:utf-8 -*-

# SpeedRetopo Add-on
# Copyright (C) 2016 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>


import bpy
from bpy.types import Operator
import bmesh
import math
from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatProperty,
                       EnumProperty)
from .ui import get_addon_preferences
from mathutils import Vector
import addon_utils

def is_bsurface_activated():
    return any('bsurfaces' in addon.lower() for addon in bpy.context.preferences.addons.keys())
    # addon_name = "bsurface"
    # return addon_name in bpy.context.preferences.addons

def is_looptools_activated():
    return any('looptools' in addon.lower() for addon in bpy.context.preferences.addons.keys())
    # addon_name = "looptools"
    # return addon_name in bpy.context.preferences.addons

# -----------------------------------------------------------------------------
#    SETUP RETOPO
# -----------------------------------------------------------------------------
class SPEEDRETOPO_OT_create_speedretopo(Operator):
    bl_idname = "object.speedretopo_create_retopo"
    bl_label = "Create Speed Retopo"
    bl_description = ("Start Retopology\n\n"
                      "You can choose between several tools and set the options you want to use in the Settings part.")
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        addonpref = get_addon_preferences()
        obj_color = addonpref.obj_color
        start_from = addonpref.start_from
        auto_add_mirror = addonpref.auto_add_mirror
        auto_add_shrinkwrap = addonpref.auto_add_shrinkwrap
        use_in_front = addonpref.use_in_front
        use_wireframe = addonpref.use_wireframe
        tool_settings = context.scene.tool_settings
        new_ref_object = context.active_object
        spg = context.window_manager.speedretopo_PropertyGroup

        if bpy.app.version < (4, 2, 0):
            bpy.ops.preferences.addon_enable(module="mesh_bsurfaces")
            bpy.ops.preferences.addon_enable(module="mesh_looptools")
            bpy.ops.preferences.addon_enable(module="mesh_f2")
            bpy.ops.wm.save_userpref()
        
        saved_location = context.scene.cursor.location.copy()

        # Prepare Grease Pencil
        tool_settings.annotation_stroke_placement_view3d = 'SURFACE'
        context.scene.tool_settings.use_snap_align_rotation = True

        # Add snap
        tool_settings.use_snap = True
        tool_settings.snap_elements_base = {'FACE'}
        tool_settings.use_snap_translate = True

        # Set cursor on selection
        bpy.ops.view3d.snap_cursor_to_selected()

        # Create Empty mesh
        face_scale = addonpref.face_scale
        bpy.ops.mesh.primitive_plane_add(size=face_scale, enter_editmode=True)
        bpy.ops.transform.translate(value=(10, 0, 0), orient_type='LOCAL',
                                    orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='LOCAL',
                                    constraint_axis=(True, False, False), mirror=True, use_proportional_edit=False,
                                    proportional_edit_falloff='SMOOTH', proportional_size=1,
                                    use_proportional_connected=False, use_proportional_projected=False, snap=True,
                                    snap_elements={'FACE'}, use_snap_project=False, snap_target='CENTER',
                                    use_snap_self=True, use_snap_edit=True, use_snap_nonedit=True,
                                    use_snap_selectable=False)
        bpy.ops.object.mode_set(mode='OBJECT')

        retopo_mesh = context.active_object

        retopo_mesh.name = new_ref_object.name + "_Retopo"
        retopo_mesh.data.name = new_ref_object.name + "_Retopo"

        retopo = context.active_object

        # SET CUSTOM PROP
        retopo_mesh["ref_obj"] = new_ref_object.name
        spg.ref_object = new_ref_object

        if is_bsurface_activated():
            context.scene.bsurfaces.SURFSK_mesh = retopo

        spg.selected_name = new_ref_object.name

        # Shade Auto smooth
        if addonpref.smooth_shading:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.shade_smooth()
            bpy.ops.object.mode_set(mode='EDIT')
            if is_bsurface_activated():
                context.scene.bsurfaces.SURFSK_shade_smooth = True
        else:
            bpy.ops.object.mode_set(mode='EDIT')
            if is_bsurface_activated():
                context.scene.bsurfaces.SURFSK_shade_smooth = False

        # SHADING
        if use_wireframe:
            context.object.show_wire = True
            context.object.show_all_edges = True

        if use_in_front:
            context.object.show_in_front = True
            if is_bsurface_activated():
                context.scene.bsurfaces.SURFSK_in_front = True

        # IF RETOPOLOGY
        if addonpref.retopology_shading :
            context.space_data.overlay.show_retopology = True
            bpy.context.space_data.shading.color_type = 'MATERIAL'

        elif addonpref.use_color_shader :
            context.space_data.shading.color_type = 'OBJECT'
            context.object.color = obj_color
            context.space_data.overlay.show_retopology = False
        else:
            context.space_data.overlay.show_retopology = False

        auto_merge = tool_settings.use_mesh_automerge

        if start_from == 'FACE':
            tool_settings.snap_target = 'CENTER'
            tool_settings.use_mesh_automerge = False

        elif start_from in  {'BSURFACE', 'POLYBUILD'}:
            tool_settings.use_mesh_automerge = True
            bpy.ops.mesh.delete(type='FACE')

        elif start_from == 'VERTEX':
            tool_settings.use_mesh_automerge = True
            bpy.ops.mesh.merge(type='CENTER')

        tool_settings.use_mesh_automerge = auto_merge

        if addonpref.change_selection_tool:
            if start_from in {'BSURFACE', 'VERTEX', 'FACE'}:
                bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
            elif start_from == 'POLYBUILD':
                bpy.ops.wm.tool_set_by_id(name="mesh_tool.poly_build", cycle=False, space_type='VIEW_3D')

        bpy.ops.object.mode_set(mode='OBJECT')

        if is_bsurface_activated():
            context.scene.bsurfaces.SURFSK_mesh = retopo
            context.scene.bsurfaces.SURFSK_guide = 'Annotation'

        # Add Mirror
        if auto_add_mirror:
            mod_mirror = retopo.modifiers.new("Mirror", 'MIRROR')
            mod_mirror.show_on_cage = True
            mod_mirror.mirror_object = new_ref_object

            mod_mirror.use_axis[0] = addonpref.use_axis_x
            mod_mirror.use_axis[1] = addonpref.use_axis_y
            mod_mirror.use_axis[2] = addonpref.use_axis_z

            mod_mirror.use_bisect_axis[0] = addonpref.use_bisect_axis_x
            mod_mirror.use_bisect_axis[1] = addonpref.use_bisect_axis_y
            mod_mirror.use_bisect_axis[2] = addonpref.use_bisect_axis_z

            mod_mirror.use_bisect_flip_axis[0] = addonpref.use_bisect_flip_axis_x
            mod_mirror.use_bisect_flip_axis[1] = addonpref.use_bisect_flip_axis_y
            mod_mirror.use_bisect_flip_axis[2] = addonpref.use_bisect_flip_axis_z

            mod_mirror.use_clip = addonpref.use_clip
            mod_mirror.use_mirror_merge = addonpref.use_mirror_merge
            # if addonpref.use_mirror_merge:
            mod_mirror.merge_threshold = addonpref.mirror_merge_threshold
            bpy.ops.object.modifier_move_to_index(modifier='Mirror', index=0)
            
        #create the vgroup
        has_vgroup = False 
        for vgroup in retopo.vertex_groups:
            if vgroup.name == "Speedretopo_freeze_unfreeze":
                has_vgroup = True
                continue
        if not has_vgroup:
            retopo.vertex_groups.new(name="Speedretopo_freeze_unfreeze")

        # Add Shrinkwrap
        if not addonpref.start_from == 'POLYBUILD':
            if auto_add_shrinkwrap:
                mod_shrinkwrap = retopo.modifiers.new("Shrinkwrap", 'SHRINKWRAP')
                mod_shrinkwrap.target = new_ref_object

                mod_shrinkwrap.wrap_method = addonpref.wrap_method
                mod_shrinkwrap.wrap_mode = addonpref.snap_mode

                mod_shrinkwrap.offset = addonpref.shrinkwrap_offset

                if addonpref.wrap_method == 'PROJECT':
                    mod_shrinkwrap.project_limit = addonpref.project_limit
                    mod_shrinkwrap.subsurf_levels = addonpref.shrinkwrap_subsurf_levels
                    # AXIS
                    mod_shrinkwrap.use_project_x = addonpref.shrinkwrap_axis_x
                    mod_shrinkwrap.use_project_y = addonpref.shrinkwrap_axis_y
                    mod_shrinkwrap.use_project_z = addonpref.shrinkwrap_axis_z

                    mod_shrinkwrap.use_negative_direction = addonpref.use_negative_direction
                    mod_shrinkwrap.use_positive_direction = addonpref.use_positive_direction

                    mod_shrinkwrap.cull_face = addonpref.cull_face
                    if addonpref.cull_face:
                        mod_shrinkwrap.use_invert_cull = addonpref.use_invert_cull

                mod_shrinkwrap.show_on_cage = True
                mod_shrinkwrap.vertex_group = "Speedretopo_freeze_unfreeze"
                mod_shrinkwrap.invert_vertex_group = True

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        # bpy.ops.mesh.select_mode(use_extend=True, use_expand=False, type='EDGE')

        if addonpref.use_fade_inactive:
            context.space_data.overlay.show_fade_inactive = True
        else:
            context.space_data.overlay.show_fade_inactive = False

        if start_from in {'VERTEX', 'FACE'}:
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')
            if start_from == 'VERTEX':
                bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            bpy.ops.transform.translate('INVOKE_DEFAULT')

        # RESTORE CURSOR
        context.scene.cursor.location = saved_location

        return {"FINISHED"}

# -----------------------------------------------------------------------------
#    Align to X
# -----------------------------------------------------------------------------
class SPEEDRETOPO_OT_align_center_edges(Operator):
    bl_idname = "object.speedretopo_align_center_edges"
    bl_label = "Align Center Edges"
    bl_description = "Align Vertices to the center of the grid"
    bl_options = {'REGISTER', 'UNDO'}

    vertices_distance : FloatProperty(
        name="vertices Distance",
        default=0.1,
        min=0.001, max=1) # type: ignore

    def execute(self, context):
        ob = context.object
        current_mode = ob.mode
        bpy.ops.object.mode_set(mode='EDIT')

        me = ob.data
        bm = bmesh.from_edit_mesh(me)

        # Get selected vertices
        selected_verts = [v for v in bm.verts if v.select]

        if selected_verts:
            for v in selected_verts:
                v.co[0] = 0
        else:
            for v in bm.verts:
                if abs(v.co[0]) < self.vertices_distance:
                    v.select_set(True)
                    v.co[0] = 0

        bm.select_mode |= {'VERT'}
        bmesh.update_edit_mesh(me)
        bm.select_flush_mode()
        # bpy.ops.object.speedretopo_set_unset_center(set_unset_center='set')
        # bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode=current_mode)

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'vertices_distance', text='Distance')

class SPEEDRETOPO_OT_add_subsurf(Operator):
    bl_idname = "object.speedretopo_add_subsurf"
    bl_label = "Add Subsurf Modifier"
    bl_description = "Add Subsurf Modifier\n\nNote:It can be used to check if the Retopo Mesh will work when subdivised"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        addonpref = get_addon_preferences()
        act_obj = context.active_object

        mod_subsurf = act_obj.modifiers.new("Subsurf", 'SUBSURF')
        mod_subsurf.show_only_control_edges = True
        mod_subsurf.show_in_editmode = False
        # mod_subsurf.show_expanded = False

        mod_subsurf.levels = addonpref.subsurf_levels
        mod_subsurf.show_only_control_edges = addonpref.show_only_control_edges

        shrinkwrap = context.active_object.modifiers.get("Shrinkwrap")
        if shrinkwrap:
            bpy.ops.object.modifier_move_up(modifier="Subsurf")
        return {'FINISHED'}

class SPEEDRETOPO_OT_remove_subsurf(Operator):
    bl_idname = "object.speedretopo_remove_subsurf"
    bl_label = "Remove Subsurf Modifier"
    bl_description = "Remove the Subsurf Modifier, you can add one more if you want"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.modifier_remove(modifier="Subsurf")
        return {"FINISHED"}

class SPEEDRETOPO_OT_apply_subsurf(Operator):
    bl_idname = "object.speedretopo_apply_subsurf"
    bl_label = "Apply Subsurf Modifier"
    bl_description = "Apply the Subsurf Modifier, you can add one more if you want"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.object.mode == "OBJECT":
            bpy.ops.object.modifier_apply(modifier="Subsurf")
        elif context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.modifier_apply(modifier="Subsurf")
            bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}

# -----------------------------------------------------------------------------
#    MIRROR
# -----------------------------------------------------------------------------
class SPEEDRETOPO_OT_add_mirror(Operator):
    bl_idname = "object.speedretopo_add_mirror"
    bl_label = "Add Mirror Modifier"
    bl_description = "Add Mirror Modifier\n\nIt will add the modifier on the X Axis"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        act_obj = context.active_object
        addonpref = get_addon_preferences()
        spg = context.window_manager.speedretopo_PropertyGroup

        mod_mirror = act_obj.modifiers.new("Mirror", 'MIRROR')
        # mod_mirror.show_expanded = False
        mod_mirror.show_on_cage = True
        mod_mirror.mirror_object = spg.ref_object

        mod_mirror.use_axis[0] = addonpref.use_axis_x
        mod_mirror.use_axis[1] = addonpref.use_axis_y
        mod_mirror.use_axis[2] = addonpref.use_axis_z

        mod_mirror.use_bisect_axis[0] = addonpref.use_bisect_axis_x
        mod_mirror.use_bisect_axis[1] = addonpref.use_bisect_axis_y
        mod_mirror.use_bisect_axis[2] = addonpref.use_bisect_axis_z

        mod_mirror.use_bisect_flip_axis[0] = addonpref.use_bisect_flip_axis_x
        mod_mirror.use_bisect_flip_axis[1] = addonpref.use_bisect_flip_axis_y
        mod_mirror.use_bisect_flip_axis[2] = addonpref.use_bisect_flip_axis_z

        mod_mirror.use_clip = addonpref.use_clip
        mod_mirror.use_mirror_merge = addonpref.use_mirror_merge
        # if addonpref.use_mirror_merge:
        mod_mirror.merge_threshold = addonpref.mirror_merge_threshold

        shrinkwrap = context.active_object.modifiers.get("Shrinkwrap")
        subsurf = context.active_object.modifiers.get("Subsurf")
        if shrinkwrap:
            bpy.ops.object.modifier_move_up(modifier=mod_mirror.name)
        if subsurf:
            bpy.ops.object.modifier_move_up(modifier=mod_mirror.name)
        return {'FINISHED'}

class SPEEDRETOPO_OT_apply_mirror(Operator):
    bl_idname = "object.speedretopo_apply_mirror"
    bl_label = "Apply Mirror Modifier"
    bl_description = "\nThis will apply the modifier, you can add one more if you want"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.object.mode == "OBJECT":
            bpy.ops.object.modifier_apply(modifier="Mirror")
        elif context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.modifier_apply(modifier="Mirror")
            bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}

class SPEEDRETOPO_OT_remove_mirror(Operator):
    bl_idname = "object.speedretopo_remove_mirror"
    bl_label = "Remove Mirror Modifier"
    bl_description = "\nThis will Remove the modifier, you can add one more if you want"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.modifier_remove(modifier="Mirror")

        return {"FINISHED"}

# -----------------------------------------------------------------------------
#    SHRINKWRAP
# -----------------------------------------------------------------------------
class SPEEDRETOPO_OT_remove_shrinkwrap(Operator):
    bl_idname = "object.speedretopo_remove_shrinkwrap"
    bl_label = "Remove Shrinkwrap Modifier"
    bl_description = "\nThis will Remove the modifier, you can add one more if you want"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.modifier_remove(modifier="Shrinkwrap")
        return {"FINISHED"}

class SPEEDRETOPO_OT_add_and_apply_shrinkwrap(Operator):
    bl_idname = "object.speedretopo_add_apply_shrinkwrap"
    bl_label = "Add and Apply Shrinkwrap Modifier"
    bl_description = "Add and Apply Shrinkwrap Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.object.speedretopo_add_shrinkwrap()
        bpy.ops.object.speedretopo_apply_shrinkwrap()
        return {'FINISHED'}

class SPEEDRETOPO_OT_apply_shrinkwrap(Operator):
    bl_idname = "object.speedretopo_apply_shrinkwrap"
    bl_label = "Apply Shrinkwrap Modifier"
    bl_description = "\nThis will apply the modifier, you can add one more if you want"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        spg = context.window_manager.speedretopo_PropertyGroup
        for mod in context.object.modifiers:
            if mod.type == 'SHRINKWRAP':
                ref = mod.target
                spg.ref_object = ref

        if context.object.mode in {"OBJECT", 'SCULPT'}:
            bpy.ops.object.modifier_apply(modifier="Shrinkwrap")
        elif context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.modifier_apply(modifier="Shrinkwrap")
            bpy.ops.object.mode_set(mode='EDIT')

        return {'FINISHED'}

class SPEEDRETOPO_OT_add_shrinkwrap(Operator):
    bl_idname = "object.speedretopo_add_shrinkwrap"
    bl_label = "Add Shrinkwrap Modifier"
    bl_description = ("Add Shrinkwrap Modifier\n\nThat will project the retopo mesh onto the Reference Mesh\n"
                      "You will need to update it from time to time\n\n"
                      "Note: It can slowdown the performances of your computer, so don't hesitate to Decimate the reference object")
    bl_options = {"REGISTER", 'UNDO'}

    def execute(self, context):
        addonpref = get_addon_preferences()
        act_obj = context.active_object
        spg = context.window_manager.speedretopo_PropertyGroup

        mirror = False
        bisect_x = False
        bisect_y = False
        bisect_z = False
        for mod in act_obj.modifiers:
            if mod.type == 'MIRROR':
                mirror = True
                if mod.use_bisect_axis[0]:
                    bisect_x = True
                if mod.use_bisect_axis[1]:
                    bisect_y = True
                if mod.use_bisect_axis[2]:
                    bisect_z = True

        # Créer un groupe de sommets s'il n'existe pas
        if "Speedretopo_freeze_unfreeze" not in act_obj.vertex_groups:
            act_obj.vertex_groups.new(name="Speedretopo_freeze_unfreeze")

        if spg.ref_object:
            # Ajouter le modificateur Shrinkwrap
            mod_shrinkwrap = act_obj.modifiers.new("Shrinkwrap", 'SHRINKWRAP')
            # mod_shrinkwrap.show_expanded = False
            mod_shrinkwrap.target = spg.ref_object
            mod_shrinkwrap.wrap_method = addonpref.wrap_method
            mod_shrinkwrap.wrap_mode = addonpref.snap_mode
            mod_shrinkwrap.offset = addonpref.shrinkwrap_offset

            if addonpref.wrap_method == 'PROJECT':
                mod_shrinkwrap.project_limit = addonpref.project_limit
                mod_shrinkwrap.subsurf_levels = addonpref.shrinkwrap_subsurf_levels
                # AXIS
                mod_shrinkwrap.use_project_x = addonpref.shrinkwrap_axis_x
                mod_shrinkwrap.use_project_y = addonpref.shrinkwrap_axis_y
                mod_shrinkwrap.use_project_z = addonpref.shrinkwrap_axis_z

                mod_shrinkwrap.use_negative_direction = addonpref.use_negative_direction
                mod_shrinkwrap.use_positive_direction = addonpref.use_positive_direction

                mod_shrinkwrap.cull_face = addonpref.cull_face
                if addonpref.cull_face:
                    mod_shrinkwrap.use_invert_cull = addonpref.use_invert_cull

            mod_shrinkwrap.show_on_cage = True
            mod_shrinkwrap.vertex_group = "Speedretopo_freeze_unfreeze"
            mod_shrinkwrap.invert_vertex_group = True

            if "Speedretopo_freeze_unfreeze" in act_obj.vertex_groups:
                mod_shrinkwrap.vertex_group = "Speedretopo_freeze_unfreeze"
                mod_shrinkwrap.invert_vertex_group = True

            # Sélectionner et aligner les sommets du centre
            act_obj_mode = context.active_object.mode
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='DESELECT')

            if "Speedretopo_set_unset_center" in act_obj.vertex_groups:
                bpy.ops.object.vertex_group_set_active(group='Speedretopo_set_unset_center')
                bpy.ops.object.vertex_group_select()
                bpy.ops.object.speedretopo_align_center_edges()

            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode=act_obj_mode)
        else:
            self.report({'WARNING'}, "No Reference object, could not finish")

        return {'FINISHED'}

def copy_shrinkwrap_modifier_and_apply():
    exclude = ('name', 'type', 'bl_rna', 'rna_type')

    active_obj = bpy.context.active_object
    # Ensure the active object is the intended target
    if active_obj is None:
        print("No active object.")
        return

    # Update the scene to ensure all data is current
    bpy.context.scene.frame_set(bpy.context.scene.frame_current)

    active_modifier = active_obj.modifiers.get("Shrinkwrap")
    if active_modifier and active_modifier.type == 'SHRINKWRAP':
        for prop in [prop.identifier for prop in active_modifier.bl_rna.properties if prop.identifier not in exclude]:
            print(f"{prop}: {getattr(active_modifier, prop)}")

        # Copy and apply the active object's Shrinkwrap modifier
        bpy.ops.object.modifier_add(type=active_modifier.type)
        new_modifier = active_obj.modifiers[-1]

        for prop in [prop.identifier for prop in active_modifier.bl_rna.properties if prop.identifier not in exclude]:
            try:
                setattr(new_modifier, prop, getattr(active_modifier, prop))
            except AttributeError:
                print(f"Skipping read-only attribute: {prop}")

        # Apply the modifier with its current settings
        bpy.ops.object.modifier_apply(modifier=new_modifier.name)


    else:
        print("No active Shrinkwrap modifier found.")

class SPEEDRETOPO_OT_update_shrinkwrap(Operator):
    bl_idname = "object.speedretopo_update_shrinkwrap"
    bl_label = "Update the Shrinkwrap Modifier"
    bl_description = "\nThe shrinkwrap Modifier is dependant of the base of the Retopo Mesh, so you will need to update it from time to time"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object

        mode = obj.mode

        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Example usage on the active object
        copy_shrinkwrap_modifier_and_apply()
        for mod in obj.modifiers:
            if mod.type == "SHRINKWRAP":
                mod.name = "Shrinkwrap"

        for vgroup in obj.vertex_groups:
            if vgroup.name == "Speedretopo_set_unset_center":
                bpy.ops.object.vertex_group_set_active(group='Speedretopo_set_unset_center')
                bpy.ops.object.mode_set(mode='EDIT')

                me = obj.data
                bm = bmesh.from_edit_mesh(me)
                bpy.ops.mesh.select_all(action='DESELECT')
                bpy.ops.object.vertex_group_select()
                selected_verts = [v for v in bm.verts if v.select]
                if selected_verts:
                    bpy.ops.object.speedretopo_align_center_edges()

                    bpy.ops.mesh.select_all(action='DESELECT')

                bmesh.update_edit_mesh(obj.data)


        bpy.ops.object.mode_set(mode=mode)

        self.report({'INFO'}, "Shrinkwrap Updated")

        return {"FINISHED"}

# -----------------------------------------------------------------------------
#    OTHERS
# -----------------------------------------------------------------------------
class SPEEDRETOPO_OT_recalculate_normals_outside(Operator):
    bl_idname = "object.speedretopo_recalculate_normals_outside"
    bl_label = "Recalculate Normals Outside"
    bl_description = "Recalculate the Normals of the Mesh Outside"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        act_obj = context.active_object
        mode = act_obj.mode
        bpy.ops.object.mode_set(mode='EDIT')
        me = act_obj.data
        bm = bmesh.from_edit_mesh(me)

        vert_selected = ([v for v in bm.verts if v.select])

        # RECALCULATE NORMAL OUTSIDE
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.mesh.select_all(action='DESELECT')

        for v in vert_selected:
            v.select = True

        bpy.ops.object.mode_set(mode='OBJECT')
        if bpy.app.version < (4, 1, 0):
            bpy.ops.object.shade_smooth(use_auto_smooth=True)
            context.object.data.auto_smooth_angle = 1.0472
        else:
            bpy.ops.object.shade_smooth()

        bpy.ops.object.mode_set(mode=mode)

        return {"FINISHED"}

class SPEEDRETOPO_OT_recalculate_normals_inside(Operator):
    bl_idname = "object.speedretopo_recalculate_normals_inside"
    bl_label = "Recalculate Normals Inside"
    bl_description = "Recalculate the Normals of the Mesh Inside"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):

        act_obj = context.active_object
        mode = act_obj.mode
        bpy.ops.object.mode_set(mode='EDIT')
        me = act_obj.data
        bm = bmesh.from_edit_mesh(me)

        vert_selected = ([v for v in bm.verts if v.select])

        # RECALCULATE NORMAL OUTSIDE
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.normals_make_consistent(inside=True)
        bpy.ops.mesh.select_all(action='DESELECT')

        for v in vert_selected:
            v.select = True

        bpy.ops.object.mode_set(mode='OBJECT')
        if bpy.app.version < (4, 1, 0):
            bpy.ops.object.shade_smooth(use_auto_smooth=True)
            bpy.context.object.data.auto_smooth_angle = 1.0472
        else:
            bpy.ops.object.shade_smooth()

        bpy.ops.object.mode_set(mode=mode)

        return {"FINISHED"}

class SPEEDRETOPO_OT_srrelax(Operator):
    bl_idname = "mesh.speedretopo_relax"
    bl_label = "Relax"
    bl_description = "Relax\n\nSmooth the Mesh and keep the volume\n\nIt will not take the boundary Mesh into account nor the vertices that are Frozen"
    bl_options = {'REGISTER', 'UNDO'}

    Repeat: bpy.props.IntProperty(
        name="Repeat",
        description="Repeat how many times",
        default=5,
        min=1,
        max=100) # type: ignore

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj and obj.type == 'MESH' and context.mode == 'EDIT_MESH')

    def invoke(self, context, event):

        # smooth #Repeat times
        for i in range(self.Repeat):
            self.do_laprelax()

        # bpy.ops.mesh.select_all(action='DESELECT')
        return {'FINISHED'}

    def do_laprelax(self):

        context = bpy.context
        region = context.region
        area = context.area
        selobj = bpy.context.active_object
        mesh = selobj.data
        bm = bmesh.from_edit_mesh(mesh)
        bmprev = bm.copy()
        vertices = [v for v in bmprev.verts if v.select]
        obj = context.active_object

        # has_vgroups = any(vgroup for vgroup in obj.vertex_groups if vgroup.name == "Speedretopo_freeze_unfreeze" or vgroup.name == "Speedretopo_set_unset_center")

        if not vertices:
            bpy.ops.mesh.select_all(action='SELECT')

        if obj.vertex_groups:
            for vgroup in obj.vertex_groups:
                if vgroup.name.startswith("Speedretopo_freeze_unfreeze") :
                # if vgroup.name.startswith("Speedretopo_freeze_unfreeze") or vgroup.name.startswith("Speedretopo_set_unset_center"):
                    obj.vertex_groups.active = vgroup
                    bpy.ops.object.vertex_group_deselect()

        # Smart Relax
        for v in bmprev.verts:

            if v.select:

                tot = Vector((0, 0, 0))
                cnt = 0
                for e in v.link_edges:
                    for f in e.link_faces:
                        if not (f.select):
                            cnt = 1
                    if len(e.link_faces) == 1:
                        cnt = 1
                        break
                if cnt:
                    # dont affect border edges: they cause shrinkage
                    continue

                # find Laplacian mean
                for e in v.link_edges:
                    tot += e.other_vert(v).co
                tot /= len(v.link_edges)

                # cancel movement in direction of vertex normal
                delta = (tot - v.co)
                if delta.length != 0:
                    ang = delta.angle(v.normal)
                    deltanor = math.cos(ang) * delta.length
                    nor = v.normal
                    nor.length = abs(deltanor)
                    bm.verts.ensure_lookup_table()
                    bm.verts[v.index].co = tot + nor

        mesh.update()
        bm.free()
        bmprev.free()
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()

class SPEEDRETOPO_OT_space_relax(Operator):
    bl_idname = "object.speedretopo_space_relax"
    bl_label = "Space Relax"
    bl_description = "Uniform vertex spacing"
    bl_options = {"REGISTER"}

    def execute(self, context):
        bpy.ops.mesh.looptools_space()
        bpy.ops.mesh.looptools_relax()

        return {"FINISHED"}

class SPEEDRETOPO_OT_symmetrize(Operator):
    bl_idname = 'object.speedretopo_symmetrize'
    bl_label = "Symmetrize MEsh"
    bl_options = {'REGISTER'}
    bl_description = "Symmetrize the Mesh on the X Axis"

    def execute(self, context):
        actobj_mode = context.object.mode
        bpy.ops.object.mode_set(mode='OBJECT')
        for mod in context.object.modifiers:
            if mod.type == 'MIRROR':
                bpy.ops.object.modifier_apply(modifier="Mirror")

        if context.object.mode != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')

        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.symmetrize(direction='POSITIVE_X')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode=actobj_mode)

        return {'FINISHED'}

class SPEEDRETOPO_OT_double_threshold_plus(Operator):
    bl_idname = "object.speedretopo_double_threshold_plus"
    bl_label = "Double Threshold 01"
    bl_description = "Set the Double Threshold at 01"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.tool_settings.double_threshold = 0.1
        return {'FINISHED'}

class SPEEDRETOPO_OT_double_threshold_minus(Operator):
    bl_idname = "object.speedretopo_double_threshold_minus"
    bl_label = "Double Threshold 0001"
    bl_description = "Set the Double Threshold at 0001"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.tool_settings.double_threshold = 0.001
        return {'FINISHED'}

class SPEEDRETOPO_OT_set_bsurface(Operator):
    bl_idname = 'object.speedretopo_set_bsurface'
    bl_label = "Set Bsurface"
    bl_description = "Set the Retopo Mesh for Bsurface"
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        if is_bsurface_activated():
            context.scene.bsurfaces.SURFSK_mesh = context.active_object
            bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}

class SPEEDRETOPO_OT_add_color(Operator):
    bl_idname = 'object.speedretopo_add_color'
    bl_label = "Add Color"
    bl_description = "Add Color Shading to the Retopo Mesh"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        if len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH']) == 1:
            return True

    def execute(self, context):
        addonpref = get_addon_preferences()
        obj_color = addonpref.obj_color

        context.space_data.shading.color_type = 'OBJECT'
        context.object.color = obj_color
        context.space_data.overlay.show_retopology = False

        return {'FINISHED'}

class SPEEDRETOPO_OT_remove_color(Operator):
    bl_idname = 'object.speedretopo_remove_color'
    bl_label = "Remove Color"
    bl_description = "Remove Color Shading from the Retopo Mesh"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        if [obj for obj in context.selected_objects if context.object is not None if obj.type == 'MESH']:
            return True

    def execute(self, context):
        context.object.color = (1, 1, 1, 1)
        return {'FINISHED'}

class SPEEDRETOPO_OT_gstretch(Operator):
    bl_idname = 'object.speedretopo_gstretch'
    bl_label = "Gstretch"
    bl_description = "Stretch selected Vertices to Active Stroke (annotation Tool)"
    bl_options = {'REGISTER'}

    @classmethod

    def poll(cls, context):
        return True

    def execute(self, context):

        lt = bpy.context.window_manager.looptools
        lt.gstretch_use_guide = 'Annotation'

        gp = context.active_object
        gp.active_material_index = 0

        bpy.ops.mesh.looptools_gstretch(conversion='limit_vertices', conversion_distance=0.1, conversion_max=32, conversion_min=8, conversion_vertices=32, delete_strokes=False, influence=100, lock_x=False, lock_y=False, lock_z=False, method='regular')

        bpy.ops.remove.annotation()
        return {'FINISHED'}

class SPEEDRETOPO_OT_decimate(Operator):
    bl_idname = "object.speedretopo_decimate"
    bl_label = "Decimate Object"
    bl_description = ("Decimate the Reference object\n\n"
                      "Your Refence Object Polycount is huge\n"
                      "You may need to reduce it with a Decimation")
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        spg = context.window_manager.speedretopo_PropertyGroup
        obj = context.active_object

        for obj in context.selected_objects:
            context.view_layer.objects.active = obj
            decimate = context.object.modifiers.get("Decimate")
            if not decimate :
                mod_decim = obj.modifiers.new("Decimate", 'DECIMATE')
                mod_decim.ratio = 0.2
                spg.edit_decimate = mod_decim.ratio
                context.object.show_wire = True

        return {"FINISHED"}

class SPEEDRETOPO_OT_apply_decimate(Operator):
    bl_idname = "object.speedretopo_apply_decimate"
    bl_label = "Apply Decimate Modifier"
    bl_description = "Apply Decimate Modifier"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.object.mode == "OBJECT":
            bpy.ops.object.modifier_apply(modifier="Decimate")

        elif context.object.mode == "EDIT":
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.modifier_apply(modifier="Decimate")
            bpy.ops.object.mode_set(mode='EDIT')

        context.object.show_wire = False
        return {'FINISHED'}

class SPEEDRETOPO_OT_remove_decimate(Operator):
    bl_idname = "object.speedretopo_remove_decimate"
    bl_label = "Remove Decimate Modifier"
    bl_description = "Remove Decimate Modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        bpy.ops.object.modifier_remove(modifier="Decimate")
        context.object.show_wire = False
        return {"FINISHED"}

class SPEEDRETOPO_OT_freeze_unfreeze(Operator):
    bl_idname = "object.speedretopo_freeze_unfreeze"
    bl_label = "Freeze/Unfreeze Selection"
    bl_description = ("Freezing Tools\n\nFREEZE: Add Selected Vertices to the Freezing Tools\n\n"
                      "UNFREEZE: Remove Selected Vertices from the Freezing Tools\n\n"
                      "SELECT: Select all the Vertices that are seted for the Freezing Tools\n\n"
                      "CLEAR: Remove all the Vertices of the mesh from the Freezing Tools\n\n"
                      "Note: The Vertices that are setted will not be edited by the Relax or the Shrinkwrap modifiers")
    bl_options = {"REGISTER","UNDO"}

    freeze_unfreeze : EnumProperty(
        items=(('freeze', "freeze", ""),
               ('unfreeze', "unfreeze", ""),
               ('clear', "clear", ""),
               ('select', "select", ""),),
        default='freeze') # type: ignore

    def execute(self, context):
        obj = context.active_object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        selected_verts = [v for v in bm.verts if v.select]
        selected_edges = [e for e in bm.edges if e.select]
        selected_faces = [f for f in bm.faces if f.select]
    
        if obj.vertex_groups.get("Speedretopo_freeze_unfreeze"):
            bpy.ops.object.vertex_group_set_active(group='Speedretopo_freeze_unfreeze')
        else:
            obj.vertex_groups.new(name="Speedretopo_freeze_unfreeze")

        if self.freeze_unfreeze == 'select':
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.vertex_group_select()

        elif self.freeze_unfreeze == 'freeze':
            if any([selected_verts,selected_edges,selected_faces]):
                bpy.ops.object.vertex_group_assign()
                self.report({'INFO'}, "Selection added To Freeze")

        elif self.freeze_unfreeze == 'unfreeze':
            if any([selected_verts, selected_edges, selected_faces]):
                bpy.ops.object.vertex_group_remove_from()
                bpy.ops.mesh.select_all(action='DESELECT')
                self.report({'INFO'}, "Selection Removed From Freeze")

        elif self.freeze_unfreeze == 'clear':
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.object.vertex_group_remove_from(use_all_verts=True)
            bpy.ops.mesh.select_all(action='DESELECT')
            self.report({'INFO'}, "Freeze has been cleared")

        return {"FINISHED"}

class SPEEDRETOPO_OT_set_freeze_tool(Operator):
    """    SET FREEZE TOOL

    CLICK - Set
    SHIFT - Select
    CTRL - Remove From Freeze
    """
    bl_idname = 'object.speedretopo_set_freeze_tool'
    bl_label = "Set Freeze Tool"
    bl_options = {'REGISTER','UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        obj = context.active_object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        selected_verts = [v for v in bm.verts if v.select]
        selected_edges = [e for e in bm.edges if e.select]
        selected_faces = [f for f in bm.faces if f.select]

        if obj.vertex_groups.get("Speedretopo_freeze_unfreeze"):
            bpy.ops.object.vertex_group_set_active(group='Speedretopo_freeze_unfreeze')
        else:
            obj.vertex_groups.new(name="Speedretopo_freeze_unfreeze")

        if event.shift:
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.vertex_group_select()

        elif event.ctrl:
            if any([selected_verts,selected_edges,selected_faces]):
                bpy.ops.object.vertex_group_remove_from()
                bpy.ops.mesh.select_all(action='DESELECT')
                self.report({'INFO'}, "Selection Removed From Freeze")
            else:
                self.report({'INFO'}, "No Selection > Cancel")

        elif event.alt:
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.object.vertex_group_remove_from(use_all_verts=True)
            bpy.ops.mesh.select_all(action='DESELECT')
            self.report({'INFO'}, "Freeze has been cleared")

        else:
            if any([selected_verts,selected_edges,selected_faces]):
                bpy.ops.object.vertex_group_assign()
                self.report({'INFO'}, "Selection added To Freeze")
            else:
                self.report({'INFO'}, "No Selection > Cancel")


        return {'FINISHED'}

class SPEEDRETOPO_OT_set_unset_center(Operator):
    bl_idname = "object.speedretopo_set_unset_center"
    bl_label = "Center Tools"
    bl_description = ("Center Tools\n\nSET: Add Selected Vertices to the Center Tools\n\n"
                      "UNSET: Remove Selected Vertices from the Center Tools\n\n"
                      "SELECT: Select all the Vertices that are seted for the Center Tools\n\n"
                      "CLEAR: Remove all the Vertices of the mesh from the Center Tools\n\n"
                      "Note: The Vertices that are setted will not be edited by the Relax or the Shrinkwrap modifiers")
    bl_options = {"REGISTER", "UNDO"}


    set_unset_center : EnumProperty(
        items=(('set', "set", ""),
               ('unset', "unset", ""),
               ('clear', "clear", ""),
               ('select', "select", ""),),
        default='set') # type: ignore

    def execute(self, context):
        obj = context.active_object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        selected_verts = [v for v in bm.verts if v.select]
        selected_edges = [e for e in bm.edges if e.select]

        if obj.vertex_groups.get("Speedretopo_set_unset_center"):
            bpy.ops.object.vertex_group_set_active(group='Speedretopo_set_unset_center')
        else:
            obj.vertex_groups.new(name="Speedretopo_set_unset_center")

        if self.set_unset_center == 'select':
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.vertex_group_select()
            bpy.ops.object.speedretopo_align_center_edges()

        elif self.set_unset_center == 'set':
            if any([selected_verts,selected_edges]):
                bpy.ops.object.vertex_group_assign()
                bpy.ops.object.speedretopo_align_center_edges()
                bpy.ops.object.speedretopo_update_shrinkwrap()
                self.report({'INFO'}, "Selection Added To Center")

        elif self.set_unset_center == 'unset':
            if any([selected_verts,selected_edges]):
                bpy.ops.object.vertex_group_remove_from()
                bpy.ops.mesh.select_all(action='DESELECT')
                self.report({'INFO'}, "Selection Removed From Center")

        elif self.set_unset_center == 'clear':
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.object.vertex_group_remove_from(use_all_verts=True)
            bpy.ops.mesh.select_all(action='DESELECT')
            self.report({'INFO'}, "Center has been cleared")

        return {"FINISHED"}

class SPEEDRETOPO_OT_set_center_tool(Operator):
    """    SET CENTER TOOL

    CLICK - Set Center
    SHIFT - Select
    CTRL - Remove From Center
    """
    bl_idname = 'object.speedretopo_set_center_tool'
    bl_label = "Set Center Tool"
    bl_options = {'REGISTER','UNDO'}

    def invoke(self, context, event):
        obj = context.active_object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        selected_verts = [v for v in bm.verts if v.select]
        selected_edges = [e for e in bm.edges if e.select]

        if obj.vertex_groups.get("Speedretopo_set_unset_center"):
            bpy.ops.object.vertex_group_set_active(group='Speedretopo_set_unset_center')
        else:
            obj.vertex_groups.new(name="Speedretopo_set_unset_center")

        if event.shift:
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.vertex_group_select()
            bpy.ops.object.speedretopo_align_center_edges()

        elif event.ctrl:
            if any([selected_verts,selected_edges]):
                bpy.ops.object.vertex_group_remove_from()
                bpy.ops.mesh.select_all(action='DESELECT')
                self.report({'INFO'}, "Selection Removed From Center")

        elif event.alt:
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.object.vertex_group_remove_from(use_all_verts=True)
            bpy.ops.mesh.select_all(action='DESELECT')
            self.report({'INFO'}, "Center has been cleared")

        else:
            if any([selected_verts,selected_edges]):
                bpy.ops.object.vertex_group_assign()
                bpy.ops.object.speedretopo_align_center_edges()
                bpy.ops.object.speedretopo_update_shrinkwrap()
                self.report({'INFO'}, "Selection Added To Center")


        return {'FINISHED'}

class SPEEDRETOPO_OT_remove_double(Operator):
    bl_idname = 'object.speedretopo_remove_double'
    bl_label = "Remove double"
    bl_description= "Merge Vertices based on their Proximity"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    threshold : FloatProperty(name="", default=0.001, min=0.0001, max=100, precision=3) # type: ignore
    use_unselected : BoolProperty(name="Unselected", default=False, description="Merge Selected To Other Unselected Vertices") # type: ignore
    use_sharp_edge_from_normals : BoolProperty(name="Sharp Edge", default=False, description="Calculate Sharp Edges Using Custom Normal Data (When Available)") # type: ignore

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'threshold', text='Threshold')
        layout.prop(self, 'use_unselected', text='Unselected')
        layout.prop(self, 'use_sharp_edge_from_normals', text='Sharp Edge')

    def execute(self, context):
        actual_mode = context.object.mode

        if context.object.mode!='EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')

        bpy.ops.mesh.remove_doubles(threshold=self.threshold, use_unselected=self.use_unselected, use_sharp_edge_from_normals=self.use_sharp_edge_from_normals)

        bpy.ops.mesh.select_all(action='DESELECT')

        bpy.ops.object.mode_set(mode=actual_mode)
        return {'FINISHED'}

class SPEEDRETOPO_OT_smooth_flat(Operator):
    bl_idname = 'object.speedretopo_smooth_flat'
    bl_label = "Smooth Shading or Flat Shading"
    bl_description = "Smooth or Flat the Shading of the Mesh"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        if bpy.app.version < (4, 1, 0):
            return True

    def execute(self, context):

        mode = context.object.mode
        bpy.ops.object.mode_set(mode='OBJECT')
        if context.object.data.use_auto_smooth == False:
            bpy.ops.object.shade_smooth(use_auto_smooth=True)
            context.object.data.auto_smooth_angle = 1.0472
        else:
            bpy.ops.object.shade_smooth(use_auto_smooth=False)
            bpy.ops.object.shade_flat()

        bpy.ops.object.mode_set(mode=mode)
        return {'FINISHED'}

class SPEEDRETOPO_OT_set_smooth(Operator):
    bl_idname = 'object.speedretopo_set_smooth'
    bl_label = "Set Smooth"
    bl_options = {'REGISTER','UNDO'}
    bl_description = "Set the Shading smooth"

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (4, 1, 0):
            return True

    def execute(self, context):
        obj = context.active_object
        current_mode = obj.mode

        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.shade_smooth()

        #Restore Mode
        bpy.ops.object.mode_set(mode=current_mode, toggle=False)

        return {'FINISHED'}

class SPEEDRETOPO_OT_set_flat(Operator):
    bl_idname = 'object.speedretopo_set_flat'
    bl_label = "Set Flat"
    bl_options = {'REGISTER','UNDO'}
    bl_description = "Set the Shading Flat"

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (4, 1, 0):
            return True

    def execute(self, context):
        obj = context.active_object
        current_mode = obj.mode

        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.shade_flat()

        #Restore Mode
        bpy.ops.object.mode_set(mode=current_mode, toggle=False)

        return {'FINISHED'}

# ----------------------------------------------------------------------------------------------------------------------
# SCULPT
# ----------------------------------------------------------------------------------------------------------------------
class SPEEDRETOPO_OT_deform(Operator):
    bl_idname = 'object.speedretopo_set_deform_brush'
    bl_label = "Deform"
    bl_description = "Deform Brush\n\nRealistic deformations such as grabbing or twisting"
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        bpy.ops.object.mode_set(mode='SCULPT')
        bpy.ops.wm.tool_set_by_id(name="builtin_brush.Elastic Deform")
        return {'FINISHED'}

class SPEEDRETOPO_OT_set_smooth_brush(Operator):
    bl_idname = 'object.speedretopo_set_smooth_brush'
    bl_label = "Smooth"
    bl_description = "Smooth Brush\n\nSmooth the surface of the Mesh, preserving Volume"
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        bpy.ops.object.mode_set(mode='SCULPT')
        bpy.ops.wm.tool_set_by_id(name="builtin_brush.Smooth")
        bpy.data.brushes["Smooth"].smooth_deform_type = 'SURFACE'

        return {'FINISHED'}

class SPEEDRETOPO_OT_reverse_alpha(Operator):
    bl_idname = "object.speedretopo_reverse_alpha"
    bl_label = "Reverse Alpha"
    bl_description = "Reverse alpha of visible objects in the 3D view"

    def execute(self, context):
        for obj in context.visible_objects:
            current_alpha = obj.color[3]
            if current_alpha == 1.0:
                obj.color[3] = 0.5
            else:
                obj.color[3] = 1.0
        return {'FINISHED'}

class SPEEDRETOPO_OT_remove_alpha(Operator):
    bl_idname = "object.speedretopo_remove_alpha"
    bl_label = "Clear color & Alpha"
    bl_description = "Clear color & Alpha of visible objects in the 3D view"

    def execute(self, context):
        for obj in context.visible_objects:
            obj.color = (1, 1, 1, 1)

        context.space_data.shading.color_type = 'MATERIAL'

        return {'FINISHED'}

CLASSES =  [SPEEDRETOPO_OT_create_speedretopo,
            SPEEDRETOPO_OT_align_center_edges,
            SPEEDRETOPO_OT_add_subsurf,
            SPEEDRETOPO_OT_remove_subsurf,
            SPEEDRETOPO_OT_apply_subsurf,
            SPEEDRETOPO_OT_add_mirror,
            SPEEDRETOPO_OT_apply_mirror,
            SPEEDRETOPO_OT_remove_mirror,
            SPEEDRETOPO_OT_remove_shrinkwrap,
            SPEEDRETOPO_OT_add_and_apply_shrinkwrap,
            SPEEDRETOPO_OT_apply_shrinkwrap,
            SPEEDRETOPO_OT_add_shrinkwrap,
            SPEEDRETOPO_OT_update_shrinkwrap,
            SPEEDRETOPO_OT_recalculate_normals_outside,
            SPEEDRETOPO_OT_recalculate_normals_inside,
            SPEEDRETOPO_OT_srrelax,
            SPEEDRETOPO_OT_space_relax,
            SPEEDRETOPO_OT_double_threshold_plus,
            SPEEDRETOPO_OT_double_threshold_minus,
            SPEEDRETOPO_OT_add_color,
            SPEEDRETOPO_OT_remove_color,
            SPEEDRETOPO_OT_symmetrize,
            SPEEDRETOPO_OT_gstretch,
            SPEEDRETOPO_OT_decimate,
            SPEEDRETOPO_OT_apply_decimate,
            SPEEDRETOPO_OT_remove_decimate,
            SPEEDRETOPO_OT_freeze_unfreeze,
            SPEEDRETOPO_OT_set_freeze_tool,
            SPEEDRETOPO_OT_set_unset_center,
            SPEEDRETOPO_OT_set_center_tool,
            SPEEDRETOPO_OT_set_bsurface,
            SPEEDRETOPO_OT_remove_double,
            SPEEDRETOPO_OT_smooth_flat,
            SPEEDRETOPO_OT_set_flat,
            SPEEDRETOPO_OT_set_smooth,
            SPEEDRETOPO_OT_deform,
            SPEEDRETOPO_OT_set_smooth_brush,
            SPEEDRETOPO_OT_reverse_alpha,
            SPEEDRETOPO_OT_remove_alpha
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")


def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

