# -*- coding:utf-8 -*-

# SpeedRetopo Add-on
# Copyright (C) 2016 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

bl_info = {
    "name": "SpeedRetopo",
    "description": "Addon for retopology",
    "author": "Cedric Lepiller, EWOC for Laprelax",
    "version": (0, 3, 1),
    "blender": (4, 2, 3),
    "location": "Property Panel, Press N in the 3DView",
    "wiki_url": "https://youtu.be/cKhZNOFc4Us",
    "doc_url": "https://blscripts.notion.site/SPEEDRETOPO-fbf23d93fa924b5da8ec096c00fd59c5",
    "category": "Object"}


import bpy
from mathutils import *
from bpy.types import Operator, Menu, AddonPreferences, PropertyGroup
from bpy.types import Object
from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       FloatVectorProperty,
                       BoolVectorProperty,
                       PointerProperty)
import urllib.request
import json
import rna_keymap_ui
from .ui import SPEEDRETOPO_PT_ui
from .icon.icons import *
from.documentation import *
# from .operators import smooth_flat_shading

# Import des modules
if "bpy" in locals():
    import importlib
    reloadable_modules = ["operators","ui","documentation"]
    for module in reloadable_modules:
        if module in locals():
            importlib.reload(locals()[module])

from . import  (operators,ui,documentation)


# -----------------------------------------------------------------------------
#    Preferences
# -----------------------------------------------------------------------------
def get_addon_preferences():
    addon_key = __package__.split(".")[0]
    return bpy.context.preferences.addons[addon_key].preferences

keymaps_items_dict = {"Speedretopo": ['object.speedretopo_ot_start_or_edit', None,
                                      '3D View ''Generic', 'VIEW_3D', 'WINDOW',
                                      'RIGHTMOUSE', 'PRESS', True, True, True]}

def update_speedretopo_category(self, context):
    is_panel = hasattr(bpy.types, 'SPEEDRETOPO_PT_ui')
    prefs = bpy.context.preferences.addons[__name__].preferences

    if is_panel:
        try:
            bpy.utils.unregister_class(bpy.types.SPEEDRETOPO_PT_ui)
        except:
            pass

    ui.SPEEDRETOPO_PT_ui.bl_category = self.category
    bpy.utils.register_class(ui.SPEEDRETOPO_PT_ui)

# Preferences
def check_for_updates_and_notify():
    # Define the addon name; usually, this should be dynamically set to __name__ in real scenarios
    addon_idname = __name__
    # print(addon_idname)

    # URL where the JSON file is hosted
    url = 'https://www.blscripts.com/blscripts_addons_updates.json'
    response = urllib.request.urlopen(url)
    data = json.load(response)

    # Get local version from bl_info directly
    local_version = bl_info['version']
    local_version_str = '.'.join(map(str, local_version))  # Convert tuple to string for comparison

    update_message = ""

    # Check for update specific to this addon
    if addon_idname in data:
        addon_data = data[addon_idname]
        if local_version_str != addon_data['version'] and addon_data['version'] > local_version_str:
            update_message = f"New version available: {addon_data['version']} (current: {local_version_str})\n"
            print(addon_idname + " New Version Available: " + addon_data['version'])
        else:
            update_message = "No updates available."
            print(addon_idname + ": No Update Available")
    else:
        update_message = "No updates available."
        print(addon_idname + ": No Update Available")

    # Set the update message in preferences
    preferences = bpy.context.preferences.addons[addon_idname].preferences
    preferences.update_available = update_message

    return update_message

class SPEEDRETOPO_OT_check_updates(bpy.types.Operator):
    bl_idname = "wm.speedretopo_check_updates"
    bl_label = "Check for Updates"

    def execute(self, context):
        check_for_updates_and_notify()
        update_message = check_for_updates_and_notify()
        self.report({'INFO'}, update_message)
        return {'FINISHED'}

class SPEEDRETOPO_MT_addon_preferences(AddonPreferences):
    bl_idname = __name__

    prefs_tabs: EnumProperty(
        items=(('info', "Info", "ADDON INFO"),
               ('options', "Options", "ADDON OPTIONS"),
               ('keymaps', "Keymaps", "CHANGE KEYMAPS"),
               ('documentation', "Documentation", "ADDON DOCUMENTATION"),
               ('links', "Links", "LINKS")),
        default='info') # type: ignore

    retopology_shading: BoolProperty(name="Hidden Wire", default=True,
                              description="Hide Faces to see through the mesh") # type: ignore
    icons = load_icons()

    icon1 = icons.get("icon_bsurface")
    icon2 = icons.get("icon_vertex")
    icon3 = icons.get("icon_polybuild")
    icon4 = icons.get("icon_face")


    start_from: EnumProperty(
        items=(
               ('VERTEX', "Vertex", "Use a single Vertex to start the retopology", icon2.icon_id, 2),
               ('FACE', "face", "Use a single Face to start the retopology", icon4.icon_id, 4),
               ('BSURFACE', "BSurface", "Use Bsurface Addon, Press D, old and draw the lines", icon1.icon_id, 1),
               ('POLYBUILD', "Polybuild", "Use Polybuild Tool", icon3.icon_id, 3),),
        default='FACE',
        name="Start Retopology From",
        description="\nStart your retopology with a simple Vertex, a Face, Bsurface or Polybuild") # type: ignore

    use_menu_or_pie_menu: EnumProperty(
        items=(('menu', "Menu", "Use Menu instead of Pie Menus"),
               ('pie_menus', "Pie Menus", "Use Pie Menus instead of Menu" )),
        default='pie_menus',
        description="Choose Menu Type") # type: ignore

    auto_add_mirror: BoolProperty(name="Auto Add Mirror", default=True, description="Add a Mirror Modifier to your retopology.") # type: ignore
    auto_add_shrinkwrap: BoolProperty(name="Auto Add Shrinkwrap", default=True, description="Add a Shrinkwrap Modifier to your retopology.") # type: ignore
    use_in_front: BoolProperty(name="Use In Front Setting", default=True,
                                   description="See the Retopo Mesh in front of the Reference Mesh") # type: ignore
    use_wireframe: BoolProperty(name="Use Wireframe", default=True,
                                   description="Show Object Wireframe") # type: ignore
    use_color_shader: BoolProperty(name="Use Color Shader", default=False,
                                   description="Add a Color to you mesh") # type: ignore
    obj_color: FloatVectorProperty(name="", default=(0, 0.65, 1, 0.5), min=0, max=1, size=4, subtype='COLOR_GAMMA',
                                   description="Choose a Color to you mesh") # type: ignore
    mirror_axis: BoolVectorProperty(default=[True, False, False], size=3, name="") # type: ignore
    mirror_clipping: BoolProperty(name="Use Mirror Clipping", default=False,
                                   description="Add a Color to you mesh") # type: ignore
    face_scale : FloatProperty(
            name="Face Scale",
            default=0.1,
            min=0.001, max=10,
            description="Size of the face created for your Retopology") # type: ignore


    buttons_size: FloatProperty(name="", default=1, min=1, max=2, precision=3) # type: ignore
    smooth_shading: BoolProperty(name="Smooth Shading", default=True,description="Use smooth shading with Auto Smooth") # type: ignore
    change_selection_tool: BoolProperty(default=True, description="Use the tewak tool") # type: ignore
    category: StringProperty(description="Choose a name for the category of the panel", default="SpeedRetopo",
                             update=update_speedretopo_category) # type: ignore

    # QUAD REMESH
    # quad_use_mesh_symmetry : BoolProperty(name="Use Mesh Symmetry", default=True,
    #                                      description="Generate a symmetrical mesh using the mesh symmetry configuration.")
    # quad_use_preserve_sharp : BoolProperty(name="Use Preserve Sharp", default=True, description="Try to preserve Sharph features on the mesh.")
    # quad_use_preserve_boundary : BoolProperty(name="Use Preserve Boundary", default=True,description="Try to preserve Boundary on the mesh.")
    # quad_preserve_paint_mask : BoolProperty(name="Use Preserve Paint Mask", default=False, description="Reproject the paint mask onto the new mesh.")
    # quad_smooth_normals : BoolProperty(name="Smooth Normals", default=True,description="Smooth the Normals of the mesh")
    # quad_mode : EnumProperty(
    #     items=(('FACES', "FACES", ""),
    #            ('RATIO', "RATIO", "" ),
    #            ('EDGE', "EDGE", "" )),
    #     default='FACES',
    #     description="Specify the amount of detail for the new mesh.")
    # quad_target_ratio : FloatProperty(name="Ratio", default=0.5, min=0.01, max=1, precision=3, description="Relative Number of Faces compared to the current Mesh.")
    # quad_target_edge_length : FloatProperty(name="Length", default=0.1, min=0.01, max=1, precision=3, description="Edges Length")
    # quad_target_faces : IntProperty(name="Number of Faces", default=1000, min=1, max=100000, description="Number of Faces")
    # quad_mesh_area : FloatProperty(name="Quad Mesh Area", default=-1, min=-1, max=1, precision=3, description="Old Object Face Area, This property is only used to cache the object area for later calculations.")
    # quad_seed : IntProperty(name="Seed", default=0, min=0, max=255, description="Random Seed to use with the Solver")

    show_retopo_settings_menu: BoolProperty(default=True, description="Set the Retopology Settings") # type: ignore
    show_modifiers_menu: BoolProperty(default=True, description="Add Modifiers to help you on your Retopology") # type: ignore
    show_tools_menu: BoolProperty(default=True, description="Use Tools to help you on your Retopology") # type: ignore
    show_shading_menu: BoolProperty(default=True, description="Set the Shadind of the Retopo Mesh") # type: ignore
    show_quadriflow_menu: BoolProperty(default=False, description="Show/Hide Quadriflow") # type: ignore
    show_freeze_unfreeze: BoolProperty(default=False, description="Freezing some vertices to not be tacking into account by the Relax or the Shrinkwrap Modifier\n\n"
                                                                  "You can Freeze, Unfreeze, select the Vertices or Clear all vertices from the Freezing Tool") # type: ignore
    show_center_tools: BoolProperty(default=True, description="Set vertices to keep them at the center no mater what\n\n"
                                                              "You can Set, Uset, select or Clear all vertices from the Center Tool") # type: ignore

    show_hide_menu_settings: BoolProperty(default=True, description="Show/Hide Menus Settings") # type: ignore
    show_hide_retopo_settings: BoolProperty(default=True, description="Show/Hide Retopology Settings") # type: ignore
    show_hide_quadremesh_settings: BoolProperty(default=False, description="Show/Hide Quad Remesh Settings") # type: ignore
    show_hide_mirror_modifiers_settings: BoolProperty(default=False, description="Show/Hide Mirror Modifiers Settings") # type: ignore
    show_hide_shrinkwrap_modifiers_settings: BoolProperty(default=False, description="Show/Hide Shrinkwrap Modifiers Settings") # type: ignore
    show_hide_subsurf_modifiers_settings: BoolProperty(default=False, description="Show/Hide Subsurf Modifiers Settings") # type: ignore

    show_help_buttons: BoolProperty(default=True, description="Show Help Buttons") # type: ignore
    reference_nbf : IntProperty(name="Number of Faces for the Reference Object", default=100000, min=10, max=500000, description="Number of Faces for the Reference Object.") # type: ignore


    # MIRROR SETTINGS
    use_axis_x: BoolProperty(name="",default=True,description="Use Mirror X Axis") # type: ignore
    use_axis_y: BoolProperty(name="",default=False,description="Use Mirror Y Axis") # type: ignore
    use_axis_z: BoolProperty(name="",default=False,description="Use Mirror Z Axis") # type: ignore

    use_bisect_axis_x: BoolProperty(name="",default=False,description="Use Mirror X Bisect Axis") # type: ignore
    use_bisect_axis_y: BoolProperty(name="",default=False,description="Use Mirror Y Bisect Axis") # type: ignore
    use_bisect_axis_z: BoolProperty(name="",default=False,description="Use Mirror Z Bisect Axis") # type: ignore

    use_bisect_flip_axis_x: BoolProperty(name="",default=False,description="Use Mirror X Bisect Flip Axis") # type: ignore
    use_bisect_flip_axis_y: BoolProperty(name="",default=False,description="Use Mirror Y Bisect Flip Axis") # type: ignore
    use_bisect_flip_axis_z: BoolProperty(name="",default=False,description="Use Mirror Z Bisect Flip Axis") # type: ignore

    use_clip: BoolProperty(name="",default=True,description="Use Clip") # type: ignore
    use_mirror_merge: BoolProperty(name="",default=True,description="Use Mirror Merge") # type: ignore
    mirror_merge_threshold: FloatProperty(name="Merge Threshold", default=0.01, min=0.001, max=100, precision=3) # type: ignore
    use_mirror_vertex_groups: BoolProperty(name="",default=True,description="Use Mirror Vertex Group") # type: ignore
    center_empty_ref: BoolProperty(name="", default=False, description="Center the Empty to the scene origin") # type: ignore
    show_on_cage: BoolProperty(name="", default=True) # type: ignore
    show_options_mirror: BoolProperty(default=False) # type: ignore

    # SHRINKWRAP SETTINGS
    shrinkwrap_axis: BoolVectorProperty(default=[True, False, False], size=3) # type: ignore

    shrinkwrap_axis_x: BoolProperty(name="",default=False,description="Use Shrinkwrap X Axis") # type: ignore
    shrinkwrap_axis_y: BoolProperty(name="",default=False,description="Use Shrinkwrap Y Axis") # type: ignore
    shrinkwrap_axis_z: BoolProperty(name="",default=False,description="Use Shrinkwrap Z Axis") # type: ignore
    shrinkwrap_offset : FloatProperty(name="Offset",default=0,description="Offset", precision=3) # type: ignore
    wrap_method : EnumProperty(
        items=(('NEAREST_SURFACEPOINT', "NEAREST_SURFACEPOINT", ""),
               ('PROJECT', "PROJECT", ""),
               ('NEAREST_VERTEX', "NEAREST_VERTEX", ""),
               ('TARGET_PROJECT', "TARGET_PROJECT", "")),
        default='PROJECT') # type: ignore

    snap_mode: EnumProperty(
        items=(('ON_SURFACE', "ON_SURFACE", ""),
               ("INSIDE", "INSIDE", ""),
               ("OUTSIDE", "OUTSIDE", ""),
               ("OUTSIDE_SURFACE", "OUTSIDE_SURFACE", ""),
               ("ABOVE_SURFACE", "ABOVE_SURFACE", "")),
        default='ABOVE_SURFACE') # type: ignore

    shrinkwrap_subsurf_levels: IntProperty(name="Subsurf Levels",default=0, min=0, max=6,description="Subsurf Levels") # type: ignore
    project_limit: FloatProperty(name="Project Limit",default=0, min=0, max=100, precision=3,description="Project Limit") # type: ignore
    use_negative_direction: BoolProperty(name="Negative",default=True,description="Negative") # type: ignore
    use_positive_direction: BoolProperty(name="Positive",default=True,description="Positive") # type: ignore
    use_invert_cull: BoolProperty(name="Invert Cull",default=False,description="Invert Cull") # type: ignore
    mirror_axis: BoolVectorProperty(default=[False, False, False], size=3, name="") # type: ignore
    cull_face: EnumProperty(
        items=(('OFF', "OFF", ""),
               ("FRONT", "FRONT", ""),
               ("BACK", "BACK", "")),
        default='OFF') # type: ignore

    # SUBSURF SETTINGS
    subsurf_levels: IntProperty(name="",default=0, min=0, max=6,description="Subsurf Levels") # type: ignore
    show_only_control_edges: BoolProperty(name="",default=True,description="Optimal Display") # type: ignore


    use_fade_inactive: BoolProperty(name="",default=True,description="Fade the Inactive Object to concentrate on the Retopology") # type: ignore
    show_polycount: BoolProperty(name="", default=True,
                                    description="Show Mesh Polycount Faces and Triangles") # type: ignore

    info: BoolProperty(
        name="",
        default=False,
        description="INFO") # type: ignore

    update_available: bpy.props.StringProperty(
        name="Update Available",
        description="Message indicating if there is an update available.",
        default="") # type: ignore

    def draw(self, context):
        layout = self.layout
        icons = load_icons()

        row = layout.row(align=True)
        row.prop(self, "prefs_tabs", expand=True)
        row.scale_y = 1.5
        if self.prefs_tabs == 'info':
            show_update = False
            if bpy.app.version < (4, 1, 0):
                show_update = True
            elif bpy.app.version >= (4, 2, 0) and bpy.context.preferences.system.use_online_access:
                    show_update = True
            
            # UPDATE
            box = layout.box()
            if show_update:
                row = box.row(align=True)
                update = True if self.update_available == "No updates available." else False
                row.alert = update
                row.label(text=self.update_available if self.update_available else "No updates available.")
                row.alert = False
                row.operator("wm.speedretopo_check_updates", text="Check for Updates", icon='FILE_REFRESH')
            
            if bpy.app.version >= (4, 2, 0):
                if not bpy.context.preferences.system.use_online_access:
                    row = box.row(align=True)
                    row.alert = True
                    row.label(text="Activate Allow Online Acess in the System/Network to check for updates", icon="ERROR")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_market")
            row.operator("wm.url_open", text="BLENDER MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/products/speedretopo"
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://pitiwazou-1.gumroad.com/l/speedretopo"
            icon = icons.get("icon_artstation")
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/marketplace/p/zdoaL/speedretopo"
            icon = icons.get("icon_flipped_normals")
            row.operator("wm.url_open", text="FLIPPED NORMALS",
                         icon_value=icon.icon_id).url = "https://flippednormals.com/product/speedretopo-35954?dst=kQBFV9Uv"

            # CUSTOMERS
            # box = layout.box()
            icon = icons.get("icon_discord")
            row = box.row(align=True)
            row.scale_y = 2
            row.operator("wm.url_open", text="SUPPORT ON DISCORD FOR CUSTOMERS",
                         icon_value=icon.icon_id).url = "https://discord.gg/8M8mFVegZ8"
            row.scale_x = 2
            row.prop(self, 'info', icon='INFO')
            if self.info:
                box = layout.box()
                split = box.split()
                col = split.column()
                row = col.row(align=True)
                row.label(text="Join our Discord community for customer support! As a valued customer, you’ll gain access to exclusive benefits:")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.label(text="1. Add-on Support Channel: To access this channel, simply send us a copy of your receipt to our email address below.")
                row = col.row(align=True)
                row.label(text="2. Latest Builds: Stay up-to-date with the latest builds of our add-ons.")
                row = col.row(align=True)
                row.label(text="3. Feature Requests: Have a feature in mind? Feel free to ask—we’re here to listen!")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.label(text="🔗 Discord Invite Link: https://discord.gg/8M8mFVegZ8")
                row = col.row(align=True)
                row.label(text="📧 Email: mail.blscripts@gmail.com")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.label(text="Thank you for supporting our work! If you haven’t purchased the add-on yet, ")
                row = col.row(align=True)
                row.label(text="consider doing so it helps sustain years of effort and support for all our add-ons.")

            box = layout.box()
            box.label(text="Welcome to SpeedRetopo, this addon allows you to make One-click Retopology.")
            box.label(text="The addon was made to be as simple to use as possible.")
            box.label(text="It also gives you all the necessary tools to work on your retopology.")





        if self.prefs_tabs == 'options':
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.label(text="",icon='MENU_PANEL')
            row.prop(self, "show_hide_menu_settings", text="MENUS SETTINGS",
                     icon='TRIA_UP' if self.show_hide_menu_settings else 'TRIA_RIGHT')
            if self.show_hide_menu_settings:

                row = box.row(align=True)
                row.label(text="Panel Category:")
                row.prop(self, "category", text="")

                row = box.row(align=True)
                row.label(text="Choose Menu Type")
                row.prop(self, "use_menu_or_pie_menu", text="")

                row = box.row(align=True)
                row.label(text="Buttons Size")
                row.prop(self, "buttons_size")

                row = box.row(align=True)
                row.label(text="Always show Modifiers menu")
                row.prop(self, "show_modifiers_menu", text="      ")

                row = box.row(align=True)
                row.label(text="Always show Tools menu")
                row.prop(self, "show_tools_menu", text="      ")

                row = box.row(align=True)
                row.label(text="Always show Shading menu")
                row.prop(self, "show_shading_menu", text="      ")

                row = box.row(align=True)
                row.label(text="Number of Faces for the Reference Object")
                row.prop(self, "reference_nbf", text="      ")

                row = box.row(align=True)
                row.label(text="Show Help in the UI")
                row.prop(self, "show_help_buttons", text="      ")

                row = box.row(align=True)
                row.label(text="Show Mesh Polycount")
                row.prop(self, "show_polycount", text="      ")

            # RETOPO
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            icon = icons.get("icon_speedretopo")
            row.label(text="", icon_value=icon.icon_id)
            row.prop(self, "show_hide_retopo_settings", text="RETOPOLOGY SETTINGS",
                     icon='TRIA_UP' if self.show_hide_retopo_settings else 'TRIA_RIGHT')

            if self.show_hide_retopo_settings:
                row = box.row(align=True)
                row.label(text="Start Retopo From")
                row.prop(self, "start_from", text="")

                if self.start_from == 'FACE':
                    row = box.row(align=True)
                    row.label(text="Face Scale")
                    row.prop(self, "face_scale", text="      ")

                row = box.row(align=True)
                row.label(text="Auto Add Mirror")
                row.prop(self, "auto_add_mirror", text="      ")

                if not self.start_from == 'POLYBUILD':
                    row = box.row(align=True)
                    row.label(text="Auto Add Shrinkwrap")
                    row.prop(self, "auto_add_shrinkwrap", text="      ")

                row = box.row(align=True)
                row.label(text="Use Tweak Tool")
                row.prop(self, "change_selection_tool", text="      ")

                row = box.row(align=True)
                row.label(text="Use Smooth Shading")
                row.prop(self, "smooth_shading", text="      ")

                row = box.row(align=True)
                row.label(text="Use Retopology Shading")
                row.prop(self, "retopology_shading", text="      ")

                row = box.row(align=True)
                row.label(text="Use Wireframe")
                row.prop(self, "use_wireframe", text="      ")

                row = box.row(align=True)
                row.label(text="Use In Front")
                row.prop(self, "use_in_front", text="      ")

                row = box.row(align=True)
                row.label(text="Use Fade Inactive")
                row.prop(self, "use_fade_inactive", text="      ")

                row = box.row(align=True)
                row.label(text="Use Color")
                row.prop(self, "use_color_shader", text="      ")


                if self.use_color_shader:
                    row = box.row(align=True)
                    row.label(text="Color")
                    row.prop(self, "obj_color")

                # MIRROR
                row = box.row(align=True)
                row.scale_y = 1.5
                icon = icons.get("icon_mirror")
                row.label(text="", icon_value=icon.icon_id)
                row.prop(self, "show_hide_mirror_modifiers_settings", text="MIRROR MODIFIER",
                         icon='TRIA_UP' if self.show_hide_mirror_modifiers_settings else 'TRIA_RIGHT')
                if self.show_hide_mirror_modifiers_settings:
                    split = box.split()
                    col1 = split.column()
                    col1.label(text="Axis")
                    col1.label(text="Bisect Axis")
                    col1.label(text="Bisect Flip Axis")

                    col2 = split.column()
                    row = col2.row(align=True)
                    row.prop(self, "use_axis_x", text="X", expand=True)
                    row.prop(self, "use_axis_y", text="Y", expand=True)
                    row.prop(self, "use_axis_z", text="Z", expand=True)

                    row = col2.row(align=True)
                    row.prop(self, "use_bisect_axis_x", text="X", expand=True)
                    row.prop(self, "use_bisect_axis_y", text="Y", expand=True)
                    row.prop(self, "use_bisect_axis_z", text="Z", expand=True)

                    row = col2.row(align=True)
                    row.prop(self, "use_bisect_flip_axis_x", text="X", expand=True)
                    row.prop(self, "use_bisect_flip_axis_y", text="Y", expand=True)
                    row.prop(self, "use_bisect_flip_axis_z", text="Z", expand=True)

                    row = box.row(align=True)
                    row.label(text="Clipping")
                    row.prop(self, "use_clip", text="      ")

                    row = box.row(align=True)
                    row.label(text="Merge")
                    row.prop(self, "use_mirror_merge", text="      ")
                    if self.use_mirror_merge:
                        row = box.row(align=True)
                        row.label(text="Merge Threshold")
                        row.prop(self, "mirror_merge_threshold")

                # SHRINKWRAP
                row = box.row(align=True)
                row.scale_y = 1.5
                icon = icons.get("icon_shrinkwrap")
                row.label(text="", icon_value=icon.icon_id)
                row.prop(self, "show_hide_shrinkwrap_modifiers_settings", text="SHRINKWRAP MODIFIER",
                         icon='TRIA_UP' if self.show_hide_shrinkwrap_modifiers_settings else 'TRIA_RIGHT')
                if self.show_hide_shrinkwrap_modifiers_settings:
                    split = box.split()
                    col = split.column()

                    row = col.row(align=True)
                    row.label(text="Wrap Method")
                    row.prop(self, "wrap_method", text="")

                    if self.wrap_method in {'NEAREST_SURFACEPOINT', 'TARGET_PROJECT', 'NEAREST_VERTEX'}:
                        row = box.row(align=True)
                        row.label(text="Snap Mode")
                        row.prop(self, "snap_mode", text="")

                    elif self.wrap_method == 'PROJECT':
                        row = box.row(align=True)
                        row.label(text="Snap Mode")
                        row.prop(self, "snap_mode", text="")

                        split = box.split()
                        col = split.column()
                        col.label(text="Project Limit:")
                        col = split.column(align=True)
                        col.prop(self, 'project_limit', expand=True)

                        split = box.split()
                        col = split.column()
                        col.label(text="Subdivision Levels:")
                        col = split.column(align=True)
                        col.prop(self, 'shrinkwrap_subsurf_levels', expand=True)

                        split = box.split()
                        col1 = split.column()
                        col1.label(text="Axis")
                        col2 = split.column()
                        row = col2.row(align=True)
                        row.prop(self, "shrinkwrap_axis_x", text="X", expand=True)
                        row.prop(self, "shrinkwrap_axis_y", text="Y", expand=True)
                        row.prop(self, "shrinkwrap_axis_z", text="Z", expand=True)

                        split = box.split()
                        col = split.column()
                        row = col.row(align=True)
                        row.label(text="Negative")
                        row.prop(self, "use_negative_direction", text="      ")

                        split = box.split()
                        col = split.column()
                        row = col.row(align=True)
                        row.label(text="Positive")
                        row.prop(self, "use_positive_direction", text="      ")

                        split = box.split()
                        col = split.column()
                        row = col.row(align=True)
                        row.label(text="Cull Faces:")
                        row.prop(self, "cull_face", text="")

                        if self.cull_face in {'FRONT', 'BACK'}:
                            split = box.split()
                            col = split.column()
                            row = col.row(align=True)
                            row.label(text="Invert Cull")
                            row.prop(self, "use_invert_cull", text="      ")

                    split = box.split()
                    col = split.column()
                    col.label(text="Offset:")
                    col = split.column(align=True)
                    col.prop(self, 'shrinkwrap_offset', expand=True)

                # SUBSURF
                row = box.row(align=True)
                row.scale_y = 1.5
                icon = icons.get("icon_subsurf")
                row.label(text="", icon_value=icon.icon_id)
                row.prop(self, "show_hide_subsurf_modifiers_settings", text="SUBSURF MODIFIER",
                         icon='TRIA_UP' if self.show_hide_subsurf_modifiers_settings else 'TRIA_RIGHT')
                if self.show_hide_subsurf_modifiers_settings:
                    split = box.split()
                    col = split.column()
                    col.label(text="Subdivision Levels:")
                    col = split.column(align=True)
                    col.prop(self, 'subsurf_levels', expand=True)

                    split = box.split()
                    col = split.column()
                    row = col.row(align=True)
                    row.label(text="Optimal Display")
                    row.prop(self, "show_only_control_edges", text="      ")

        # KEYMAPS
        if self.prefs_tabs == 'keymaps':
            wm = bpy.context.window_manager
            draw_keymap_items(wm, layout)

        if self.prefs_tabs == 'documentation':
            doc(self, context)


        # Links
        if self.prefs_tabs == 'links':

            # TUTORIALS
            box = layout.box()
            row = box.row(align=True)
            row.label(text="TUTORIALS & ADD-ONS")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://pitiwazou-1.gumroad.com/"

            row = box.row(align=True)
            row.scale_y = 1.3
            row.operator("wm.url_open", text="GUMROAD - SPEEDFLOW",
                         icon_value=icon.icon_id).url = "https://pitiwazou.gumroad.com/"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_market")
            row.operator("wm.url_open", text="MARKET",
                         icon_value=icon.icon_id).url = "https://blendermarket.com/creators/pitiwazou"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_artstation")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/a/651436"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_flipped_normals")
            row.operator("wm.url_open", text="FLIPPED NORMALS",
                         icon_value=icon.icon_id).url = "https://flippednormals.com/creator/pitiwazou?tagIds=1"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_youtube")
            row.operator("wm.url_open", text="YOUTUBE",
                         icon_value=icon.icon_id).url = "https://www.youtube.com/user/pitiwazou"

            # LINKS
            box = layout.box()
            row = box.row(align=True)
            row.label(text="SOCIAL")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_web")
            row.operator("wm.url_open", text="PITIWAZOU.COM",
                         icon_value=icon.icon_id).url = "http://www.pitiwazou.com/"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_artstation")
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/artist/pitiwazou"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_twitter")
            row.operator("wm.url_open", text="TWITTER",
                         icon_value=icon.icon_id).url = "https://twitter.com/#!/pitiwazou"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_facebook")
            row.operator("wm.url_open", text="FACEBOOK",
                         icon_value=icon.icon_id).url = "https://www.facebook.com/Pitiwazou-C%C3%A9dric-Lepiller-120591657966584/"

# -----------------------------------------------------------------------------
#    Keymap
# -----------------------------------------------------------------------------
addon_keymaps = []

def draw_keymap_items(wm, layout):
    kc = wm.keyconfigs.user

    for name, items in keymaps_items_dict.items():
        kmi_name, kmi_value, km_name = items[:3]
        box = layout.box()
        split = box.split()
        col = split.column()
        col.label(text=name)
        col.separator()
        km = kc.keymaps[km_name]
        get_hotkey_entry_item(kc, km, kmi_name, kmi_value, col)

def get_hotkey_entry_item(kc, km, kmi_name, kmi_value, col):
    # for menus and pie_menu
    if kmi_value:
        for km_item in km.keymap_items:
            if km_item.idname == kmi_name and km_item.properties.name == kmi_value:
                col.context_pointer_set('keymap', km)
                rna_keymap_ui.draw_kmi([], kc, km, km_item, col, 0)
                return

        col.label(text=f"No hotkey entry found for {kmi_value}")
        col.operator(SPEEDRETOPO_OT_Add_Hotkey.bl_idname, icon='ADD')

    # for operators
    else:
        if km.keymap_items.get(kmi_name):
            col.context_pointer_set('keymap', km)
            rna_keymap_ui.draw_kmi(
                [], kc, km, km.keymap_items[kmi_name], col, 0)
        else:
            col.label(text=f"No hotkey entry found for {kmi_name}")
            col.operator(SPEEDRETOPO_OT_Add_Hotkey.bl_idname, icon='ADD')

class SPEEDRETOPO_OT_Add_Hotkey(bpy.types.Operator):
    ''' Add hotkey entry '''
    bl_idname = "template_rmb.add_hotkey"
    bl_label = "Add Hotkeys"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        add_hotkey()

        self.report({'INFO'},
                    "Hotkey added in User Preferences -> Input -> Screen -> Screen (Global)")
        return {'FINISHED'}

def add_hotkey():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon

    if not kc:
        return

    for items in keymaps_items_dict.values():
        kmi_name, kmi_value, km_name, space_type, region_type = items[:5]
        eventType, eventValue, ctrl, shift, alt = items[5:]
        km = kc.keymaps.new(name=km_name, space_type=space_type,
                            region_type=region_type)

        kmi = km.keymap_items.new(kmi_name, eventType,
                                  eventValue, ctrl=ctrl, shift=shift,
                                  alt=alt

                                  )
        if kmi_value:
            kmi.properties.name = kmi_value

        kmi.active = True

    addon_keymaps.append((km, kmi))

def remove_hotkey():
    ''' clears all addon level keymap hotkeys stored in addon_keymaps '''

    kmi_values = [item[1] for item in keymaps_items_dict.values() if item]
    kmi_names = [item[0] for item in keymaps_items_dict.values() if item not in ['wm.call_menu', 'wm.call_menu_pie']]

    for km, kmi in addon_keymaps:
        # remove addon keymap for menu and pie menu
        if hasattr(kmi.properties, 'name'):
            if kmi_values:
                if kmi.properties.name in kmi_values:
                    km.keymap_items.remove(kmi)

        # remove addon_keymap for operators
        else:
            if kmi_names:
                if kmi.name in kmi_names:
                    km.keymap_items.remove(kmi)

    addon_keymaps.clear()

# -----------------------------------------------------------------------------
#    PROPERTYGROUP
# -----------------------------------------------------------------------------

def ref_obj_update(self, context):

    if self.ref_object:
        context.active_object["ref_obj"] = self.ref_object.name if self.ref_object else None

        for mod in context.active_object.modifiers:
            if mod.type == 'SHRINKWRAP':
                mod.target = self.ref_object
            if mod.type == 'MIRROR':
                mod.mirror_object = self.ref_object
    else:
        if context.active_object.get("ref_obj"):
            del context.active_object["ref_obj"]

        for mod in context.active_object.modifiers:
            if mod.type == 'SHRINKWRAP':
                mod.target = None
            if mod.type == 'MIRROR':
                mod.mirror_object = None
# import time
# def update_decimate_ratio(self, context):
#
#     for obj in bpy.data.objects:
#         for mod in obj.modifiers:
#             if mod.type == 'DECIMATE':
#                 mod.show_viewport = False
#                 mod.ratio = self.edit_decimate
#                 time.sleep(1)
#                 mod.show_viewport = True
#                 depsgraph = context.evaluated_depsgraph_get()
#                 depsgraph.update()
#                 bpy.context.area.tag_redraw()
def update_decimate_ratio(self, context):
    obj = context.active_object
    for mod in obj.modifiers:
        if mod.type == 'DECIMATE':
            mod.ratio = self.edit_decimate

    # Force update of the dependency graph
    depsgraph = context.evaluated_depsgraph_get()
    depsgraph.update()

    evaluated_obj = obj.evaluated_get(depsgraph)
    faces = evaluated_obj.data.polygons
    face_count = len(faces)
    triangle_count = sum(len(poly.vertices) - 2 for poly in faces)

    self.face_count = face_count
    self.triangle_count = triangle_count

    # Redraw the area
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            area.tag_redraw()

class SPEEDRETOPO_PropertyGroup(PropertyGroup):
    show_doc_intro: BoolProperty(default=True, description="Show/Hide Introduction") # type: ignore
    show_doc_start: BoolProperty(default=True, description="Show/Hide Starting Your Retopology") # type: ignore
    show_doc_ref: BoolProperty(default=True, description="Show/Hide Reference Object") # type: ignore
    show_doc_modifiers: BoolProperty(default=False, description="Show/Hide Modifiers") # type: ignore
    show_doc_tools: BoolProperty(default=False, description="Show/Hide Tools") # type: ignore
    show_doc_shading: BoolProperty(default=False, description="Show/Hide Shading") # type: ignore
    show_doc_start_cont_fin: BoolProperty(default=False, description="Show/Hide Start Continue Finalize") # type: ignore
    show_doc_prefs: BoolProperty(default=False, description="Show/Hide Preferences") # type: ignore
    show_retopo_settings: BoolProperty(name="",default=False, description="Retopology Settings\n\nSelect the Tool you want to use (Vertex, Face, etc) and the options for your Retopology") # type: ignore
    show_reference: BoolProperty(default=False, description="Show/Hide Reference Object") # type: ignore

    ref_object: PointerProperty(name="",
                                type=bpy.types.Object,
                                description="Reference Object Used for the Retopology\n\nThis Object will also be used if you add Modifiers (Mirror, Shrinkwrap)",
                                update=ref_obj_update) # type: ignore
    selected_name : StringProperty() # type: ignore

    face_count: IntProperty(name="Face Count", default=0) # type: ignore
    triangle_count: IntProperty(name="Triangle Count", default=0) # type: ignore
    last_mod_state: StringProperty() # type: ignore

    edit_decimate : FloatProperty(
            name="Decimate Ratio",
            default=0.5,
            min=0.001, max=1,
    update =update_decimate_ratio) # type: ignore

    def get_transparency(self):
        ob = bpy.context.active_object
        return ob.color[3]
    def set_transparency(self, value):
        for ob in bpy.context.selected_objects:
            ob.color[3] = value
        bpy.context.space_data.shading.color_type = 'OBJECT'
        if bpy.context.object.mode == 'EDIT' and bpy.context.object.color[3] < 1:
            bpy.context.space_data.overlay.show_wireframes = False

    transparency: FloatProperty(
        name="Object Transparency",
        description='Object Transparency\n\n'
                    'Set the Object Transparent to see through it',
        default=0.3,
        min=0, max=1,
        get=get_transparency,
        set=set_transparency) # type: ignore
    def get_color(self):
        obj = bpy.context.object
        if obj:
            return obj.color
        else:
            return (1, 1, 1, 1)
    def set_color(self, value):
        bpy.context.space_data.shading.color_type = 'OBJECT'
        for obj in bpy.context.selected_objects:
            obj.color = value
    obj_color: FloatVectorProperty(
        name="Object Color",
        default=(1, 1, 1, 1),
        min=0, max=1,
        size=4,
        subtype='COLOR_GAMMA',
        description="Choose a Color for your mesh",
        get=get_color,
        set=set_color) # type: ignore

    def update_mesh_info(self, obj):
        depsgraph = bpy.context.evaluated_depsgraph_get()
        evaluated_obj = obj.evaluated_get(depsgraph)
        faces = evaluated_obj.data.polygons
        self.face_count = len(faces)
        self.triangle_count = sum(len(poly.vertices) - 2 for poly in faces)
        # print("Mesh info updated.")

    def get_modifiers_state(self, obj):
        # Generate a string that represents the state of all modifiers' show_viewport properties
        return ','.join([f"{mod.name}:{mod.show_viewport}" for mod in obj.modifiers])

CLASSES =  [SPEEDRETOPO_MT_addon_preferences,
            SPEEDRETOPO_OT_Add_Hotkey,
            SPEEDRETOPO_PropertyGroup,
            SPEEDRETOPO_OT_check_updates]

# -----------------------------------------------------
# REGISTERS
# -----------------------------------------------------
def register():
    operators.register()
    ui.register()
    documentation.register()

    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

    # Update Category
    context = bpy.context
    prefs = context.preferences.addons[__name__].preferences
    update_speedretopo_category(prefs, context)

    # PropertyGroup
    # Object.speedretopo_ref_object = PointerProperty(name="", type=Object)
    bpy.types.WindowManager.speedretopo_PropertyGroup = PointerProperty(type=SPEEDRETOPO_PropertyGroup)

    add_hotkey()


    # CHECK FOR UPDATE
    check_update = False
    if bpy.app.version < (4, 2, 0):
        check_update = True

    if bpy.app.version >= (4, 2, 0) and bpy.context.preferences.system.use_online_access:
        check_update = True
        
    if check_update:
        check_for_updates_and_notify()

    # bpy.app.handlers.depsgraph_update_post.append(update_counts)

def unregister():
    operators.unregister()
    ui.unregister()
    documentation.unregister()

    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

    remove_hotkey()

    # bpy.app.handlers.depsgraph_update_post.remove(update_counts)